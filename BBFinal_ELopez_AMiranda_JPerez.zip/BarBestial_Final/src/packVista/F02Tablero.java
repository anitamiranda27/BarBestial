package packVista;


import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.awt.Color;
import java.awt.Dimension;

import packModelo.Camaleon;
import packModelo.Canguro;
import packModelo.Carta;
import packModelo.Fila;

import packModelo.Juego;
import packModelo.Jugador;
import packModelo.ListaDatosJugador;
import packModelo.Loro;
import packModelo.NoHayCartasEnElMazoException;
import packModelo.Ordenador;

import java.util.Observable;
import java.util.Observer;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JDialog;

public class F02Tablero extends JFrame implements Observer {

	private JPanel contentPane;
	private JButton carta1;
	private JButton carta2;
	private JButton carta3;
	private JButton carta4;
	private JLabel f1;
	private JLabel f2;
	private JLabel f3;
	private JLabel f4;
	private JLabel f5;
	private JButton MazoJugador1_1;
	private boolean hayQueRobar;
	private JLabel Ordenador1;
	private JLabel Ordenador2;
	private JLabel Ordenador3;
	private JLabel Ordenador4;
	private JLabel gorila;
	private JLabel esLoQueHay;
	private Carta carta;
	private JButton btnSaberMas;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					F02Tablero frame = new F02Tablero();
					frame.setVisible(true);
					frame.hayQueRobar=false;
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public F02Tablero() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(F02Tablero.class.getResource("/packImagenes/bb.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1441, 797);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 250, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		gorila = new JLabel("");
		gorila.setVerticalAlignment(SwingConstants.TOP);
		gorila.setBounds(200, 200, 150, 250);
		
		ImageIcon MyImage = new ImageIcon(getClass().getResource("/packImagenes/Gorila.JPG"));	
		Image img = MyImage.getImage();
		Image newImg = img.getScaledInstance(gorila.getWidth(),gorila.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image = new ImageIcon(newImg);
		gorila.setIcon(image);
		
		JLabel BarBestial = new JLabel("");
		BarBestial.setVerticalAlignment(SwingConstants.TOP);
		BarBestial.setBounds(200, 200, 250, 150);
		ImageIcon MyImage2 = new ImageIcon(getClass().getResource("/packImagenes/BarBestial.PNG"));		
		Image img2 = MyImage2.getImage();
		Image newImg2 = img2.getScaledInstance(BarBestial.getWidth(),BarBestial.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image2 = new ImageIcon(newImg2);
		BarBestial.setIcon(image2);
		
		esLoQueHay = new JLabel("");
		esLoQueHay.setVerticalAlignment(SwingConstants.TOP);
		esLoQueHay.setBounds(200, 200, 250, 150);
		ImageIcon MyImage3 = new ImageIcon(getClass().getResource("/packImagenes/EsLoQueHay.PNG"));		
		Image img3 = MyImage3.getImage();
		Image newImg3 = img3.getScaledInstance(esLoQueHay.getWidth(),esLoQueHay.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image3 = new ImageIcon(newImg3);
		esLoQueHay.setIcon(image3);
		
		JLabel PatadaEnElCulo = new JLabel("");
		PatadaEnElCulo.setVerticalAlignment(SwingConstants.TOP);
		PatadaEnElCulo.setBounds(200, 200, 250, 150);
		ImageIcon MyImage4 =  new ImageIcon(getClass().getResource("/packImagenes/PatadaEnElCulo.PNG"));
		Image img4 = MyImage4.getImage();
		Image newImg4 = img4.getScaledInstance(PatadaEnElCulo.getWidth(),PatadaEnElCulo.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image4 = new ImageIcon(newImg4);
		PatadaEnElCulo.setIcon(image4);
		
		MazoJugador1_1 = new JButton("");
		MazoJugador1_1.setVerticalAlignment(SwingConstants.TOP);
		MazoJugador1_1.setBounds(200, 200, 150, 250);
		ImageIcon MyImage5 = new ImageIcon(getClass().getResource("/packImagenes/Mazo.PNG"));
		Image img5 = MyImage5.getImage();
		Image newImg5 = img5.getScaledInstance(MazoJugador1_1.getWidth(),MazoJugador1_1.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image5 = new ImageIcon(newImg5);
		MazoJugador1_1.setIcon(image5);
		MazoJugador1_1.addActionListener(new ControladorMazoJugador());
		MazoJugador1_1.setActionCommand("mazo");
		
		
		carta1 = new JButton("");
		carta1.setBounds(200, 200, 150, 250);
		carta1.addActionListener(new ControladorCartas());
		carta1.setActionCommand("1");
		
		carta2 = new JButton("");
		carta2.setBounds(200, 200, 150, 250);
		carta2.addActionListener(new ControladorCartas());
		carta2.setActionCommand("2");
		
		carta3 = new JButton("");
		carta3.setBounds(200, 200, 150, 250);
		carta3.addActionListener(new ControladorCartas());
		carta3.setActionCommand("3");
		
		carta4 = new JButton("");
		carta4.setBounds(200, 200, 150, 250);
		carta4.addActionListener(new ControladorCartas());
		carta4.setActionCommand("4");
		
		f1 = new JLabel("New label");
		f1.setIcon(new ImageIcon(F02Tablero.class.getResource("/packImagenes/FondoFila.png")));
		
		f2 = new JLabel("New label");
		f2.setIcon(new ImageIcon(F02Tablero.class.getResource("/packImagenes/FondoFila.png")));
		
		f3 = new JLabel("New label");
		f3.setIcon(new ImageIcon(F02Tablero.class.getResource("/packImagenes/FondoFila.png")));
		
		f4 = new JLabel("New label");
		f4.setIcon(new ImageIcon(F02Tablero.class.getResource("/packImagenes/FondoFila.png")));
		
		f5 = new JLabel("New label");
		f5.setIcon(new ImageIcon(F02Tablero.class.getResource("/packImagenes/FondoFila.png")));
		
		Ordenador1 = new JLabel("");
		Ordenador1.setBackground(new Color(238, 232, 170));
		Ordenador1.setBounds(200, 200, 150, 150);
		ImageIcon MyImage6 = new ImageIcon(getClass().getResource("/packImagenes/Reverso.png"));
		Image img6 = MyImage6.getImage();
		Image newImg6 = img6.getScaledInstance(Ordenador1.getWidth(),Ordenador1.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image6 = new ImageIcon(newImg6);
		Ordenador1.setIcon(image6);
		
		Ordenador2 = new JLabel("");
		Ordenador2.setBackground(new Color(238, 232, 170));
		Ordenador2.setBounds(200, 200, 150, 150);
		Ordenador2.setIcon(image6);
		
		Ordenador3 = new JLabel("");
		Ordenador3.setBackground(new Color(238, 232, 170));
		Ordenador3.setBounds(200, 200, 150, 150);
		Ordenador3.setIcon(image6);
		
		Ordenador4 = new JLabel("");
		Ordenador4.setBackground(new Color(238, 232, 170));
		Ordenador4.setBounds(200, 200, 150, 150);
		Ordenador4.setIcon(image6);
		
		btnSaberMas = new JButton("Saber Mas...");
		btnSaberMas.setBackground(new Color(210, 105, 30));
		btnSaberMas.addActionListener(new Controlador());
		btnSaberMas.setActionCommand("saber");
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(42)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(182)
									.addComponent(carta1, GroupLayout.PREFERRED_SIZE, 185, GroupLayout.PREFERRED_SIZE)
									.addGap(58)
									.addComponent(carta2, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE)
									.addGap(65)
									.addComponent(carta3, GroupLayout.PREFERRED_SIZE, 175, GroupLayout.PREFERRED_SIZE)
									.addGap(77)
									.addComponent(carta4, GroupLayout.PREFERRED_SIZE, 174, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 103, Short.MAX_VALUE)
									.addComponent(btnSaberMas)
									.addGap(37))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(BarBestial, GroupLayout.PREFERRED_SIZE, 247, GroupLayout.PREFERRED_SIZE)
											.addGap(72))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(f1, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.UNRELATED)))
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(Ordenador1, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(Ordenador2, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(Ordenador3, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addComponent(Ordenador4, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(11)
											.addComponent(f2, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(f3, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(f4, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(f5, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)))
									.addPreferredGap(ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(PatadaEnElCulo)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(esLoQueHay, GroupLayout.PREFERRED_SIZE, 250, GroupLayout.PREFERRED_SIZE)
											.addGap(9))))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(15)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(MazoJugador1_1, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
								.addComponent(gorila, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE))
							.addGap(1205)))
					.addGap(52))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
							.addComponent(BarBestial)
							.addComponent(Ordenador3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(Ordenador2, GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
							.addComponent(Ordenador4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createSequentialGroup()
								.addContainerGap()
								.addComponent(PatadaEnElCulo)))
						.addComponent(Ordenador1))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(36)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(f1, GroupLayout.PREFERRED_SIZE, 248, GroupLayout.PREFERRED_SIZE)
									.addComponent(f2, GroupLayout.PREFERRED_SIZE, 248, GroupLayout.PREFERRED_SIZE)
									.addComponent(f3, GroupLayout.PREFERRED_SIZE, 248, GroupLayout.PREFERRED_SIZE)
									.addComponent(f4, GroupLayout.PREFERRED_SIZE, 248, GroupLayout.PREFERRED_SIZE)
									.addComponent(f5, GroupLayout.PREFERRED_SIZE, 248, GroupLayout.PREFERRED_SIZE))
								.addComponent(gorila)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(81)
							.addComponent(esLoQueHay)))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(34)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(carta4, GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
									.addContainerGap())
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(carta3, GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
									.addContainerGap())
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(carta2, GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
									.addContainerGap())
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(carta1, GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
									.addContainerGap())
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(MazoJugador1_1)
									.addGap(15))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(142)
							.addComponent(btnSaberMas)
							.addContainerGap())))
		);
		contentPane.setLayout(gl_contentPane);
		setTitle("Bar Bestial");
		Jugador.getJugador().addObserver(this);
		Ordenador.getOrdenador().addObserver(this);
		Juego.getJuego().addObserver(this);
		
		// Codigo para centrar el frame
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();// Tamaño del frame actual (ancho x alto)
		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}
		setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

	}
	
	public JButton getCarta1(){
		return carta1;
	}
	
	public JButton getCarta2(){
		return carta2;
	}
	
	public JButton getCarta3(){
		return carta3;
	}
	
	public JButton getCarta4(){
		return carta4;
	}
	
	private void mostrarCartasOrdenador(){
		int size = Ordenador.getOrdenador().getManoSize();
		
		if (size==3){
			Ordenador4.setVisible(false);
		} else if (size==2){
			Ordenador3.setVisible(false);
		} else if (size==1){
			Ordenador2.setVisible(false);
		} else if (size==0){
			Ordenador1.setVisible(false);
		} 
	}
		

	public void mostrarCartasFila(){
		int pos = Fila.getFila().getSize();

			if(pos == 1){
				f1.setIcon(Fila.getFila().getUnaCarta(0).getImagen());
				f2.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
				f3.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
				f4.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
				f5.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
			} else if(pos == 2){
				f1.setIcon(Fila.getFila().getUnaCarta(0).getImagen());
				f2.setIcon(Fila.getFila().getUnaCarta(1).getImagen());
				f3.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
				f4.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
				f5.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
			} else if(pos == 3){
				f1.setIcon(Fila.getFila().getUnaCarta(0).getImagen());
				f2.setIcon(Fila.getFila().getUnaCarta(1).getImagen());
				f3.setIcon(Fila.getFila().getUnaCarta(2).getImagen());
				f4.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
				f5.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
			} else if(pos == 4){
				f1.setIcon(Fila.getFila().getUnaCarta(0).getImagen());
				f2.setIcon(Fila.getFila().getUnaCarta(1).getImagen());
				f3.setIcon(Fila.getFila().getUnaCarta(2).getImagen());
				f4.setIcon(Fila.getFila().getUnaCarta(3).getImagen());
				f5.setIcon(new ImageIcon(getClass().getResource("/packImagenes/FondoFila.png")));
			} else if(pos == 5){
				f1.setIcon(Fila.getFila().getUnaCarta(0).getImagen());
				f2.setIcon(Fila.getFila().getUnaCarta(1).getImagen());
				f3.setIcon(Fila.getFila().getUnaCarta(2).getImagen());
				f4.setIcon(Fila.getFila().getUnaCarta(3).getImagen());
				f5.setIcon(Fila.getFila().getUnaCarta(4).getImagen());
			}
	}
		
	private void moverCartasIzquierda(int pos){
		if (pos==1){
			carta1.setIcon(carta2.getIcon());
			carta2.setIcon(carta3.getIcon());
			carta3.setIcon(carta4.getIcon());
			carta4.setVisible(false);
		} else if (pos==2){
			carta2.setIcon(carta3.getIcon());
			carta3.setIcon(carta4.getIcon());
			carta4.setVisible(false);
		} else if (pos==3){
			carta3.setIcon(carta4.getIcon());
			carta4.setVisible(false);
		} else {
			carta4.setVisible(false);
		}
		
	}
	
	private void moverCartasManoIzquierda(int pos){
		if (Jugador.getJugador().mazoVacio() && Jugador.getJugador().getManoSize() <3){	
			if(Jugador.getJugador().getManoSize()==2){
				moverCartasIzquierda(pos);
				carta3.setVisible(false);
			} else if (Jugador.getJugador().getManoSize()==1){
				moverCartasIzquierda(pos);
				carta2.setVisible(false);
			}else {
				carta1.setVisible(false);
			}
		} else {
			moverCartasIzquierda(pos);
		}
	}
	private void finPartida() throws IOException, ClassNotFoundException{
		JOptionPane.showMessageDialog(rootPane, "EL JUEGO SE HA ACABADO");
		JOptionPane.showMessageDialog(rootPane, "EL GANADOR ES: " + Juego.getJuego().ganador());
		
		//Ordenar el Array por puntuaciones
		ListaDatosJugador.getListaDatos().ordenar();
		
		//Guardar ListaDatosJugadores
		File f = new File("ListaDatos.dat");
		FileOutputStream fout = new FileOutputStream(f, false);
		ObjectOutputStream out = new ObjectOutputStream(fout);
		out.writeObject(ListaDatosJugador.getListaDatos().getLista());
		out.flush();
		out.close();
		
		Juego.getJuego().resetear();
		F00Principal ppal = new F00Principal();
		Juego.getJuego().inicializarJuego();
		
		//MOSTRAR RANKING
		dispose();
		F01Ranking ranking = new F01Ranking(ListaDatosJugador.getListaDatos().enviarDatosRanking());
		ranking.setVisible(true);

		
	}
	private void mensajeCambioTurno(){
		if (Juego.getJuego().esTurnoJugador()){
			JOptionPane.showMessageDialog(rootPane, "TURNO DE: "+Jugador.getJugador().getNombre());
		} else {
			JOptionPane.showMessageDialog(rootPane, "TURNO DE: ORDENADOR");
		}
	}
	
	@Override
	public void update(Observable arg0, Object arg1) {
		if (arg1.equals("cambioTurno")) {
			mensajeCambioTurno();
		} else if (arg1.equals("finJuego")){
			try {
				finPartida();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		} else if (arg1.equals("cartaEchadaOrdenador")){
			mostrarCartasFila();
		} 
	}
	
	
	
	private class ControladorCartas extends WindowAdapter implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String action = e.getActionCommand();
			if(!hayQueRobar)
			{
				if (action.equals("1")) {
					carta = Jugador.getJugador().echarCarta(0);
					moverCartasManoIzquierda(1);		
				} else if (action.equals("2")) {
					 carta = Jugador.getJugador().echarCarta(1);
					moverCartasManoIzquierda(2);
				} else if (action.equals("3")) {
					carta = Jugador.getJugador().echarCarta(2);
					moverCartasManoIzquierda(3);
				} else if (action.equals("4")) {
					carta = Jugador.getJugador().echarCarta(3);
					moverCartasManoIzquierda(4);
				}
				mostrarCartasFila();
				if (carta.getAnimal() instanceof Canguro){
					eleccion("ELIGE SI QUIERES ADELANTAR 1 O 2 POSICIONES");
				} else if (carta.getAnimal() instanceof Loro){
					eleccion("ELIGE LA POSICION DE LA FILA DEL ANIMAL AL QUE QUIERES AHUYENTAR");
 				} else if (carta.getAnimal() instanceof Camaleon){
 					eleccion("ELIGE LA POSICION DE LA FILA DEL ANIMAL AL QUE QUIERES COPIAR");
 				}  else {
					carta.getAnimal().hacerAnimalada(null);
				}
				mostrarCartasFila();
				
				// ANIMALADAS RECURRENTES
				Fila.getFila().hacerAnimaladasRecurrente();
	
				Fila.getFila().revisarEstadoFila();
				if(!(Jugador.getJugador().mazoVacio()))
				{
					hayQueRobar = true;
					JOptionPane.showMessageDialog(rootPane, "ROBA UNA CARTA DEL MAZO");
				} else {
					Juego.getJuego().cambiarTurno();
					mostrarCartasFila();
					mostrarCartasOrdenador();
				}
			}
			else{
				JOptionPane.showMessageDialog(rootPane, "NO PUEDES ECHAR CARTA, TIENES QUE ROBAR");
			}
				
		}
	
	}
	
	private class ControladorMazoJugador extends WindowAdapter implements ActionListener{

		public void actionPerformed(ActionEvent arg0) {
			String action = arg0.getActionCommand();
			if(action.equals("mazo")) {
				  try{
					if(!(Jugador.getJugador().manoLlena()))
					{
						Carta c = Jugador.getJugador().cogerCarta();
						ImageIcon robada = c.getImagen();
						carta4.setIcon(robada);
						carta4.setVisible(true);
						hayQueRobar = false;
						Juego.getJuego().cambiarTurno();
						mostrarCartasOrdenador();
						mostrarCartasFila();
					}
					else
					{
						JOptionPane.showMessageDialog(rootPane, "NO PUEDES ROBAR MAS, TIENES 4 CARTAS EN LA MANO");
					}
					
				  } catch (NoHayCartasEnElMazoException ex){
					  JOptionPane.showMessageDialog(rootPane, "NO TE QUEDAN CARTAS EN EL MAZO");
					  MazoJugador1_1.setEnabled(false);
					  hayQueRobar = false;
					  mostrarCartasFila();
				  }
			}
		}
	}
	
	public void eleccion(String titulo){
		if (Juego.getJuego().esTurnoJugador()){
			String eleccion = JOptionPane.showInputDialog(rootPane,titulo,
			JOptionPane.QUESTION_MESSAGE);
			try{
				carta.hacerAnimalada(eleccion);
			} catch (IndexOutOfBoundsException e){
				eleccion("INTRODUCE UNA POSICION VALIDA");
			}
			
		} else {
			carta.hacerAnimalada(null);
		}	
	}
	
	private class Controlador extends WindowAdapter implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			String action = e.getActionCommand();
			if(action.equals("saber")) {
				String nl =  System.getProperty("line.separator");
				JOptionPane.showMessageDialog(rootPane, "CREADORES DE LA APLICACION: "
						+nl+ ""
						+nl+ "	-Edurne Lopez"
						+nl+ "	-Ana Miranda" 
						+nl+ "	-Javier Perez" 
						+nl+ ""
						+nl+ "�DISFRUTA DEL JUEGO!"
						+nl+ ""
						+nl+ "Idea Original del Juego: ZACATRUS"
						+nl+ "	Compralo en: https://zacatrus.es/bar-bestial.html");
			}
			
		}
		
	}
}
