package packVista;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import packModelo.DatosJugador;
import packModelo.ListaDatosJugador;

import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;

public class F01Ranking extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel model;
	private JButton btnVolver;

	/**
	 * Create the frame.
	 */

	public F01Ranking(JSONArray pDatos){
		
		setResizable(false);
		setTitle("Bar Bestial");
		setIconImage(Toolkit.getDefaultToolkit().getImage(F01Ranking.class.getResource("/packImagenes/bb.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 653, 418);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		
		JLabel lblRanking = new JLabel("RANKING");
		lblRanking.setFont(new Font("Buxton Sketch", Font.PLAIN, 50));
		
		model = new DefaultTableModel()
		{
			@Override
			public boolean isCellEditable(int rowIndex, int mColIndex) 
			{
			    return false;
			}
		};
	  
	  //A�adir las columnas de la tabla
	  model.addColumn("Nombre Usuario");
	  model.addColumn("Puntuacion");

	  //A�adir las filas a la tabla desde el fichero JSON
	  for (int i = 0; i < pDatos.size()-1; i++) 
	  {
	   JSONObject one = (JSONObject) pDatos.get(i);
	   model.addRow(new Object[]{one.get("usuario"), one.get("puntuacion")});
	  }

	  table = new JTable(model);
	  table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
	  
	  //Para centrar los datos de la tabla
	  DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
	  tcr.setHorizontalAlignment(SwingConstants.CENTER);
	  table.setModel(model);
	  table.getColumnModel().getColumn(0).setCellRenderer(tcr);
	  table.getColumnModel().getColumn(1).setCellRenderer(tcr);
	  
	  table.setVisible(true);
		
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setFont(new Font("Buxton Sketch", Font.BOLD, 22));
		
		JLabel lblPuntuacion = new JLabel("Puntuacion");
		lblPuntuacion.setFont(new Font("Buxton Sketch", Font.BOLD, 22));
		
		btnVolver = new JButton("Volver");
		btnVolver.setBackground(new Color(255, 165, 0));
		btnVolver.addActionListener(new Controlador());
		btnVolver.setActionCommand("volver");
	  
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnVolver)
					.addGap(177)
					.addComponent(lblRanking)
					.addContainerGap(210, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(143)
					.addComponent(lblUsuario)
					.addPreferredGap(ComponentPlacement.RELATED, 209, Short.MAX_VALUE)
					.addComponent(lblPuntuacion)
					.addGap(124))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(table, GroupLayout.PREFERRED_SIZE, 614, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblRanking)
							.addGap(13)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblUsuario)
								.addComponent(lblPuntuacion)))
						.addComponent(btnVolver))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(table, GroupLayout.PREFERRED_SIZE, 240, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		
		// Codigo para centrar el frame
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}
		setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);	
	}
	
	private class Controlador extends WindowAdapter implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String action = e.getActionCommand();
			if(action.equals("volver"))
			{
				F00Principal ppal;
				try {
					ppal = new F00Principal();
					ppal.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {	
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
			
			}
		}
	}
}
	

