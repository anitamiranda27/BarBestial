package packVista;


import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import packModelo.Juego;
import packModelo.Jugador;
import packModelo.ListaDatosJugador;
import packModelo.Ordenador;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Toolkit;

public class F03Login extends JFrame {


	private JPanel contentPane;
	private JTextField txtNombre;
	private JPasswordField txtPassword;
	
	/**
	 * Create the frame.
	 */
	
	public F03Login() 
	{
		setIconImage(Toolkit.getDefaultToolkit().getImage(F03Login.class.getResource("/packImagenes/bb.jpg")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNombre = new JLabel("Nombre");
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		
		JLabel lblContrasea = new JLabel("Contrase\u00f1a");
		
		txtPassword = new JPasswordField();
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new Controlador());
		btnAceptar.setActionCommand("aceptar");
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new Controlador());
		btnCancelar.setActionCommand("cancelar");
		
		JLabel lblIniciaSesin = new JLabel("INICIA SESI\u00d3N");
		lblIniciaSesin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(102)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblContrasea)
								.addComponent(lblNombre))
							.addGap(49)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(txtPassword)
								.addComponent(txtNombre, GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(138)
							.addComponent(btnAceptar)
							.addGap(31)
							.addComponent(btnCancelar))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(156)
							.addComponent(lblIniciaSesin, GroupLayout.PREFERRED_SIZE, 174, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(82, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(24)
					.addComponent(lblIniciaSesin, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtNombre, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNombre))
					.addGap(31)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblContrasea)
						.addComponent(txtPassword, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancelar)
						.addComponent(btnAceptar))
					.addGap(19))
		);
		contentPane.setLayout(gl_contentPane);
		
		// Codigo para centrar el frame
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();// Tamaño del frame actual (ancho x alto)
		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}
		setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
		
		
	}
	
	private class Controlador extends WindowAdapter implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String action = e.getActionCommand();
			if (action.equals("aceptar")){
				// comprobar datos correctos
				if (ListaDatosJugador.getListaDatos().comprobarDatos(txtNombre.getText(), txtPassword.getText())){ //true

					Jugador.getJugador().setNombre(txtNombre.getText());
					F02Tablero frame02 = new F02Tablero();
					frame02.setVisible(true);
					
					JButton j = frame02.getCarta1();
					ImageIcon icon = Jugador.getJugador().getUnaCartaMano(0).getImagen();
					j.setIcon(icon);
					
					JButton j2 = frame02.getCarta2();
					ImageIcon icon2 = Jugador.getJugador().getUnaCartaMano(1).getImagen();
					j2.setIcon(icon2);
					
					JButton j3 = frame02.getCarta3();
					ImageIcon icon3 = Jugador.getJugador().getUnaCartaMano(2).getImagen();
					j3.setIcon(icon3);
					
					JButton j4 = frame02.getCarta4();
					ImageIcon icon4 = Jugador.getJugador().getUnaCartaMano(3).getImagen();
					j4.setIcon(icon4);
		
					dispose();
					
					if (!Juego.getJuego().esTurnoJugador()){
						JOptionPane.showMessageDialog(rootPane, "TURNO DE: ORDENADOR");
						Ordenador.getOrdenador().jugarOrdenador(); 
						frame02.mostrarCartasFila();
					} else {
						JOptionPane.showMessageDialog(rootPane, "TURNO DE: "+Jugador.getJugador().getNombre());
					}
					
				} else {
					JOptionPane.showMessageDialog(rootPane, "LOS DATOS INTRODUCIDOS NO SON CORRECTOS");
				}
			} else if (action.equals("cancelar")){
				F00Principal frame0;
				try {
					frame0 = new F00Principal();
					frame0.setVisible(true);
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
			}
		}
	}
}
