package packVista;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.json.simple.JSONArray;

import packMain.Main;
import packModelo.Juego;
import packModelo.Jugador;
import packModelo.ListaDatosJugador;
import packModelo.Ordenador;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.LayoutStyle.ComponentPlacement;

public class F00Principal extends JFrame implements Serializable {

	private JPanel contentPane;
	private JButton btnRegistro;
	private JButton btnLogin;
	private JButton btnRanking;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					F00Principal frame = new F00Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public F00Principal() throws ClassNotFoundException, IOException {
		
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(F00Principal.class.getResource("/packImagenes/bb.jpg")));
		setTitle("Bar Bestial");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 617, 683);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		btnRegistro = new JButton("REGISTRO");
		btnRegistro.setBackground(new Color(255, 215, 0));
		btnRegistro.addActionListener(new Controlador());
		btnRegistro.setActionCommand("registro");
		
		btnLogin = new JButton("LOGIN/JUGAR");
		btnLogin.setBackground(new Color(255, 215, 0));
		btnLogin.addActionListener(new Controlador());
		btnLogin.setActionCommand("login");
		
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(F00Principal.class.getResource("/packImagenes/Principal (1).png")));
		
		btnRanking = new JButton("RANKING");
		btnRanking.addActionListener(new Controlador());
		btnRanking.setActionCommand("ranking");

		btnRanking.setBackground(new Color(255, 165, 0));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 606, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGap(76)
					.addComponent(btnRegistro)
					.addPreferredGap(ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
					.addComponent(btnRanking, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
					.addGap(98)
					.addComponent(btnLogin)
					.addGap(65))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnLogin, GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
						.addComponent(btnRanking, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnRegistro, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 579, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
		
		// Codigo para centrar el frame
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();// Tamaño del frame actual (ancho x alto)
		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}
		setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

	}
	
	private class Controlador extends WindowAdapter implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String action = e.getActionCommand();
			if(action.equals("registro"))
			{
				F04Registro reg = new F04Registro();
				reg.setVisible(true);
				dispose();
			
			}
			else if (action.equals("login"))
			{
				F03Login log = new F03Login();
				log.setVisible(true);
				dispose();
	
			}
			else if (action.equals("ranking"))
			{
				JSONArray pDatos = ListaDatosJugador.getListaDatos().enviarDatosRanking();
				F01Ranking rank = new F01Ranking(pDatos);
				rank.setVisible(true);
				dispose();
				
			}
		}
	
	}

}
