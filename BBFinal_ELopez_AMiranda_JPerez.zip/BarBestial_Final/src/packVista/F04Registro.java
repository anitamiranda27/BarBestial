package packVista;



import javax.swing.JFrame;
import javax.swing.JPanel;

import packModelo.ListaDatosJugador;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JPasswordField;

public class F04Registro extends JFrame implements Observer{

	private JPanel contentPane;
	private JTextField txtNombre;
	private JPasswordField txtPassword1;
	private JPasswordField txtPassword2;


	/**
	 * Create the frame.
	 */
	public F04Registro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(F04Registro.class.getResource("/packImagenes/bb.jpg")));
		setResizable(false);
		getContentPane().setForeground(Color.BLACK);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JLabel nombre = new JLabel("Nombre");
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		
		JLabel password = new JLabel("Contrase\u00f1a");
		
		JLabel lblRepiteContrasea = new JLabel("Repite la contrase\u00f1a");
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new Controlador());
		btnAceptar.setActionCommand("aceptar");
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new Controlador());
		btnCancelar.setActionCommand("cancelar");
		
		JLabel lblRegistrate = new JLabel("REGISTRATE");
		lblRegistrate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		txtPassword1 = new JPasswordField();
		
		txtPassword2 = new JPasswordField();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(123)
							.addComponent(btnAceptar, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
							.addGap(30)
							.addComponent(btnCancelar, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(86)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(password)
								.addComponent(nombre)
								.addComponent(lblRepiteContrasea))
							.addGap(29)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(txtPassword2)
								.addComponent(txtPassword1)
								.addComponent(txtNombre, GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))))
					.addContainerGap(81, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(152, Short.MAX_VALUE)
					.addComponent(lblRegistrate, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE)
					.addGap(150))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(21)
					.addComponent(lblRegistrate, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtNombre, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(nombre))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(password)
						.addComponent(txtPassword1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(24)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblRepiteContrasea)
						.addComponent(txtPassword2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAceptar)
						.addComponent(btnCancelar))
					.addGap(17))
		);
		getContentPane().setLayout(groupLayout);
		ListaDatosJugador.getListaDatos().addObserver(this);
		
		// Codigo para centrar el frame
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();// Tamaño del frame actual (ancho x alto)
		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}
		setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
		
	}
	
	private class Controlador extends WindowAdapter implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String action = e.getActionCommand();
			if (action.equals("aceptar")){
				if(ListaDatosJugador.getListaDatos().registrarUsuario(txtNombre.getText(),txtPassword1.getText(),txtPassword2.getText())){
					F03Login frame03 = new F03Login();
					frame03.setVisible(true);
					dispose();
				}
			} else if(action.equals("cancelar")) {
				F00Principal frame0;
				try {
					frame0 = new F00Principal();
					frame0.setVisible(true);
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
			}
		}
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		
		if (arg1.equals("existeUsuario")) {
			JOptionPane.showMessageDialog(rootPane, "YA HAY UN USUARIO CON ESE NOMBRE");
		} else if (arg1.equals("contrasenasDistintas")){
			JOptionPane.showMessageDialog(rootPane, "LAS CONTRASEÑAS NO COINCIDEN");
		}
	}
}
