package packModelo;

public class Jugador extends Usuario{

	private static Jugador mJugador;
	private String nombre;
	
	private Jugador (){
		super();
	}

	public static Jugador getJugador() {
		if (mJugador==null){
			mJugador = new Jugador();
		}
		return mJugador;
	}
	
	public Carta echarCarta(int pPos){
		return  mano.echarCarta(pPos);	
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public void setNombre(String pNombre)
	{
		nombre = pNombre;
	}

	public void resetear() //JUNITS
	{
		mJugador = null;
	}
	
	public Carta getUnaCartaMano(int pPos){
		return mano.getUnaCarta(pPos);
	}
}