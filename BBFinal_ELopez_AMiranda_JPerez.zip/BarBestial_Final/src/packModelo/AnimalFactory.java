package packModelo;

public class AnimalFactory {

	private static AnimalFactory mAnimalFactory;

	private AnimalFactory() {		
	}

	public static AnimalFactory getAnimalFactory() {
		if (mAnimalFactory==null){
			mAnimalFactory = new AnimalFactory();
		}
		return mAnimalFactory;
	}

	/**
	 * 
	 * @param pTipo
	 */
	public Animal crearAnimal(int pTipo) {
		
		Animal a = null;
		
		if (pTipo==1){
			a = new Mofeta();
		} else if (pTipo==2){
			a = new Loro();
		} else if (pTipo==3){
			a = new Canguro();
		} else if (pTipo==4){
			a = new Mono();
		} else if (pTipo==5){
			a = new Camaleon();
		} else if (pTipo==6){
			a = new Foca();
		} else if (pTipo==7){
			a = new Cebra();
		} else if (pTipo==8){
			a = new Jirafa();
		} else if (pTipo==9){
			a = new Serpiente();
		} else if (pTipo==10){
			a = new Cocodrilo();
		} else if (pTipo==11){
			a = new Hipopotamo();
		} else if (pTipo==12){
			a = new Leon();
		}
		return a;	
	}

}