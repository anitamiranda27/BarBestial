package packModelo;

import java.io.IOException;
import java.util.Observable;
import java.util.concurrent.ThreadLocalRandom;

public class Juego extends Observable {

	private int turno; // ordenador --> turno=0   jugador --> turno=1
	private static Juego mJuego;

	private Juego() {
	}
	
	public static Juego getJuego(){
		if (mJuego==null){
			mJuego = new Juego();
		}
		return mJuego;
	}
	
	public void inicializarJuego() throws ClassNotFoundException, IOException {
		//Cargar Datos
		ListaDatosJugador.getListaDatos().cargarDatos();
		
		Jugador.getJugador().repartirCartas("Azul"); 
		Ordenador.getOrdenador().repartirCartas("Verde");
		escogerTurno();
		
	}

	public boolean finJuego() {

		if ((!Ordenador.getOrdenador().tieneCartas()) && (!Jugador.getJugador().tieneCartas())) {
			return true;
		} else {
			return false;
		}
	}

	private void escogerTurno() {
		turno = ThreadLocalRandom.current().nextInt(0,2);
	}
	
	
	public void cambiarTurno(){

		if (finJuego()){
			setChanged();
			notifyObservers("finJuego");
		} else {
			if (turno==0){
				if (Jugador.getJugador().tieneCartas()){
					turno=1;
					setChanged();
					notifyObservers("cambioTurno");
				} else {
					Ordenador.getOrdenador().jugarOrdenador();
				}
			} else {
				if (Ordenador.getOrdenador().tieneCartas()){
					turno=0;
					setChanged();
					notifyObservers("cambioTurno");
					Ordenador.getOrdenador().jugarOrdenador();
				}
			}
		}		
	}
	

	public String ganador(){
		
		String ganador;
		if  (BarBestial.getBarBestial().numCartas("Azul") > BarBestial.getBarBestial().numCartas("Verde")){
			ganador = Jugador.getJugador().getNombre();
			ListaDatosJugador.getListaDatos().sumarPuntos(ganador);
			
		} else if (BarBestial.getBarBestial().numCartas("Azul") < BarBestial.getBarBestial().numCartas("Verde")) {
			 ganador = "Ordenador";
		
		} else {
			
			if (BarBestial.getBarBestial().puntosCartas("Azul") < BarBestial.getBarBestial().puntosCartas("Verde")){
				ganador = Jugador.getJugador().getNombre();
				ListaDatosJugador.getListaDatos().sumarPuntos(ganador);

			} else if (BarBestial.getBarBestial().puntosCartas("Azul") > BarBestial.getBarBestial().puntosCartas("Verde")) {
				ganador = "Ordenador";
			} else {
				ganador = "Empate";
			}
		}
		return ganador;
	}

	public boolean esTurnoJugador(){
		return turno==1;
	}
	
	public void resetear()
	{
		Fila.getFila().resetear();
		mJuego = null;
		getJuego();
	}
	
}