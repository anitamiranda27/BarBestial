package packModelo;

import java.io.Serializable;

public class DatosJugador implements Serializable{
	int puntuacion;
	String nombre;
	String pwd;
	
	public DatosJugador(String pNombre, String pPwd) {
		this.nombre = pNombre;
		this.pwd = pPwd;
		this.puntuacion = 0;
	}
	
	public void sumarPunto() {
		this.puntuacion++;
	}
	
	public int getPuntuacion() {
		return this.puntuacion;
	}
	
	public boolean datosCorrectos(String pNombre, String pPwd)
	{
		return nombre.equals(pNombre) && pwd.equals(pPwd);
	}
	
	public boolean nombreCorrecto(String pNombre)
	{
		return nombre.equals(pNombre);
	}
	
	public String getNombre()
	{
		return nombre;
	}
}
