package packModelo;


public abstract class Animal {

	private int fuerza;

	public Animal(int pFuerza) {
		fuerza = pFuerza;
	}

	public abstract void hacerAnimalada(String eleccion);

	public int getFuerza(){
		return this.fuerza;
	}
	
	public boolean mayorfuerza(Animal pAnimal){
		if (fuerza > pAnimal.fuerza){
			return true;
		} else {
			return false;
		}
	}
	
	public boolean fuerzaMayor(int pFuerza){
		if (fuerza > pFuerza){
			return true;
		} else {
			return false;
		}
	}
}