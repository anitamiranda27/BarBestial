package packModelo;

public class Hipopotamo extends Animal implements IRecurrente {


	public Hipopotamo() {
		super(11);
	}

	public void hacerAnimalada(String eleccion) {
		/* Pasa por delante de todos excepto de los de su propia especie,
		 * los leones o las cebras
		 */
		
		Fila.getFila().animaladaHipopotamo(this);
	}
}