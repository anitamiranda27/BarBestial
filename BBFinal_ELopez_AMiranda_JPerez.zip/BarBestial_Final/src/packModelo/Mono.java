package packModelo;

public class Mono extends Animal{


	public Mono() {
		super(4);
	}

	public void hacerAnimalada(String eleccion) {
		/* Si solo hay un mono no hace nada
		 * Si hay mas de uno envian a EsLoQueHay a los hipopotamos y a los cocodrilos
		 * El mono que ha jugado en dicho turno se cuela delante de todos colocandose el primero en la cola
		 * detras de el se colocan los demas mono de la cola en orden inverso
		 */
		
		Fila.getFila().animaladaMono();
	}
}