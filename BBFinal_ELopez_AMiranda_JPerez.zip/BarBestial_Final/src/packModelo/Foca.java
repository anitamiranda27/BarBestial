package packModelo;


public class Foca extends Animal {


	public Foca() {
		super(6);
	}

	public void hacerAnimalada(String eleccion) {
		/* Cambia de sitio la carta de dar patada con la de la Puerta del cielo
		 */
		
		Fila.getFila().ordenarOrdenInverso();
	}

}