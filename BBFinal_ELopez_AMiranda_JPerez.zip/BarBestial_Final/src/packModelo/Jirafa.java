package packModelo;

public class Jirafa extends Animal implements IRecurrente {


	public Jirafa() {
		super(8);
	}
	
	
	public void hacerAnimalada(String eleccion) {	
		/* Se cuela delante de un animal mas debil
		 * Solo se puede colar delante de un animal por turno
		 */
		
		Fila.getFila().animaladaJirafa(this);
	}
}