package packModelo;

public class Leon extends Animal {


	public Leon() {
		super(12);
	}

	public void hacerAnimalada(String eleccion) {
		/*  Si hay un leon en la cola, se va a EsLoQueHay
		 * Si no hay ningun leon en la cola, manda a todos los monos a EsloQueHay 
		 * y se coloca el primero en la fila
		 */
		
		Fila.getFila().animaladaLeon();
			
	}
}