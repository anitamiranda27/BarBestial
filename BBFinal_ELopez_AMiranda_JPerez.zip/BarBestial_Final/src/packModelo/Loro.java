package packModelo;

import java.util.concurrent.ThreadLocalRandom;

public class Loro extends Animal {


	public Loro() {
		super(2);
	}

	public void hacerAnimalada(String eleccion) throws IndexOutOfBoundsException{
		/* El loro ahuyenta a un animal de la cola y lo manda a EsLoQueHay
		 * Dicho animal lo elige el jugador 
		*/
		
		int pos=0;
	
		if (eleccion!=null){	
			if (eleccion.equals("1")){
				pos = 0;
			} else if (eleccion.equals("2")){
				pos = 1;
			} else if (eleccion.equals("3")){
				pos = 2;
			} else if (eleccion.equals("4")){
				pos = 3;
			}  else {
				throw new IndexOutOfBoundsException();
			}
		} else { // envia una carta aleatoria a EsLoQueHay
			pos = ThreadLocalRandom.current().nextInt(0,Fila.getFila().getSize()-1);
		}
		Fila.getFila().animaladaLoro(pos);
	}
}