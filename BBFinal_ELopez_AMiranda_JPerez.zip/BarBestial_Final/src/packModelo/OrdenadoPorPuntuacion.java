package packModelo;

import java.util.Comparator;

public class OrdenadoPorPuntuacion implements Comparator<DatosJugador> {


	@Override
	public int compare(DatosJugador d1, DatosJugador d2) {
		return d2.getPuntuacion() - d1.getPuntuacion();
	}

}
