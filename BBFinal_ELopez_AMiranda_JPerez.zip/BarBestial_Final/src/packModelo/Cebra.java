package packModelo;

public class Cebra extends Animal implements IRecurrente{


	public Cebra() {
		super(7);
	}


	public void hacerAnimalada(String eleccion) {
		/* No pueden ser adelantadas por los hipopotamos ni por los cocodrilos
		 * tampoco pueden ser comidas
		 */
		
	}
}