package packModelo;

import java.util.Observable;

public abstract class Usuario extends Observable{

	protected ListaCartas mazo;
	protected ListaCartas mano;
	private String color;

	public Usuario() {
		mano = new ListaCartas();
		mazo = new ListaCartas();
	}

	public Carta cogerCarta() throws NoHayCartasEnElMazoException{
		
		Carta c = mazo.cogerCarta(0);
		mano.anadirCarta(c);
		return c;
	}

	public void repartirCartas(String pColor) {
		AnimalFactory factoria = AnimalFactory.getAnimalFactory();
		for (int i=1; i<=12; i++){
			Animal animal = factoria.crearAnimal(i);
			mazo.anadirCarta(new Carta(pColor, animal));
		}
		this.color = pColor;
		mazo.barajar();
		try{
			for(int i = 0; i<=3; i++){
				cogerCarta();
			}
		} catch (NoHayCartasEnElMazoException e){
			e.printStackTrace();
		}
	}
	
	public boolean tieneCartas() {
		return !mano.estaVacia();
	}
	
	public boolean manoLlena(){
		return (4 == mano.getSize() );
	}
	
	public int getManoSize(){
		return mano.getSize();
	}
	
	public boolean mazoVacio(){
		return mazo.estaVacia();
	}
}