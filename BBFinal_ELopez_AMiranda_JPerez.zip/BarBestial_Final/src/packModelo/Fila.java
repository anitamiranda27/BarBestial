package packModelo;


public class Fila {

	private ListaCartas fila;
	private static Fila mFila;

	private Fila() {
		fila = new ListaCartas();
	}

	public static Fila getFila() {
		if (mFila==null){
			mFila = new Fila();
		}
		return mFila;
	}

	

	public void anadirCarta(Carta pCarta) {
		fila.anadirCarta(pCarta);
	}
	
	public Carta getUnaCarta(int pPos){
		if(pPos<fila.getSize()) {
			return fila.getUnaCarta(pPos);
		}else {
			return null;
		}
	}

	public void eliminarCarta(Carta pCarta){	//JUNITS
		fila.eliminarCarta(pCarta);
	}
	
	public int getSize(){
		return fila.getSize();
	}
	
	public void setNull(){		//JUNITS
		fila = new ListaCartas();
	}
	
	
	public void animaladaLoro(int pPos){
		fila.animaladaLoro(pPos);
	}
	
	
	public void ordenarPorFuerza(){
		fila.ordenarPorFuerza();
	}
	
	public void hacerAnimaladasRecurrente(){
		fila.hacerAnimaladasRecurrente();
	}
	
	public void hacerAnimalada(int pos){		//JUNITS
		fila.hacerAnimalada(pos);
	}
	
	public int posicionCarta(Animal pAnimal){	//JUNITS
		return fila.posicionCarta(pAnimal);
	}
	
	public void revisarEstadoFila(){
		fila.revisarEstadoFila();
	}
	
	public void animaladaMofeta(){
		fila.animaladaMofeta();
	}
	
	public void animaladaLeon(){
		fila.animaladaLeon();
	}
	
	public void animaladaMono(){
		fila.animaladaMono();
	}
	
	public void animaladaCocodrilo(Animal pAnimal){
		fila.animaladaCocodrilo(pAnimal);
	}
	
	public void animaladaHipopotamo(Animal pAnimal){
		fila.animaladaHipopotamo(pAnimal);
	}
	
	public void animaladaJirafa(Animal pAnimal){
		fila.animaladaJirafa(pAnimal);
	}
	
	public void animaladaCamaleon(Animal pAnimal , int pPos){
		fila.animaladaCamaleon(pAnimal, pPos);
	}
	
	public void animaladaCanguro(int pPos){
		fila.animaladaCanguro(pPos);
	}
	
	public void ordenarOrdenInverso(){
		fila.ordenarOrdenInverso();
	}
	
	public void resetear()
	{
		mFila = null;
		getFila();
	}
}