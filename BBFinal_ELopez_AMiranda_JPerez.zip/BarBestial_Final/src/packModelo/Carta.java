package packModelo;


import javax.swing.ImageIcon;

public class Carta {

	private String color;
	private Animal animal;
	private ImageIcon imagen;


	public Carta(String pColor, Animal pAnimal) {
		color = pColor;
		animal = pAnimal;
		asignarImagenCarta(color, pAnimal.getFuerza());
	}
	
	public ImageIcon getImagen(){
		return imagen;
	}
	
	public boolean colorIgual(String pColor){
		return color.equals(pColor);
	}
	
	public Animal getAnimal(){
		return animal;
	}
	
	private void asignarImagenCarta(String pColor, int pFuerza){
		if(pColor.equals("Azul")) {
			if (pFuerza==1){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/AMofeta.PNG"));
			}
			else if(pFuerza==2){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/ALoro.PNG"));
			}
			else if(pFuerza==3){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/ACanguro.PNG"));
			}
			else if(pFuerza==4){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/AMono.PNG"));
			}
			else if(pFuerza==5){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/ACamaleon.PNG"));
			}
			else if(pFuerza==6){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/AFoca.PNG"));
			}
			else if(pFuerza==7){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/ACebra.PNG"));
			}
			else if(pFuerza==8){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/AJirafa.PNG"));
			}
			else if(pFuerza==9){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/ASerpiente.PNG"));
			}
			else if(pFuerza==10){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/ACocodrilo.PNG"));
			}
			else if(pFuerza==11){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/AHipopotamo.PNG"));
			}
			else if(pFuerza==12){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/ALeon.PNG"));
			}
		
		}else{
			if (pFuerza==1){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VMofeta.png"));
			}
			else if(pFuerza==2){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VLoro.png"));
			}
			else if(pFuerza==3){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VCanguro.png"));
			}
			else if(pFuerza==4){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VMono.png"));
			}
			else if(pFuerza==5){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VCamaleon.png"));
			}
			else if(pFuerza==6){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VFoca.png"));
			}
			else if(pFuerza==7){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VCebra.png"));
			}
			else if(pFuerza==8){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VJirafa.PNG"));
			}
			else if(pFuerza==9){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VSerpiente.png"));
			}
			else if(pFuerza==10){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VCocodrilo.png"));
			}
			else if(pFuerza==11){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VHipopotamo.png"));
			}
			else if(pFuerza==12){
				 imagen = new ImageIcon(getClass().getResource("/packImagenes/VLeon.PNG"));
				
			}
		}
	}
	
	public boolean mayorFuerza(Animal pAnimal){
		return animal.mayorfuerza(pAnimal);
	}
		
	public boolean esElMismoAnimal(String pAnimal){
		return nombreAnimal().equals(pAnimal);
	}
	
	public boolean fuerzaMayor(int fuerza){
		return animal.fuerzaMayor(fuerza);
	}
	
	public boolean esRecurrente(){
		return animal instanceof IRecurrente;
	}
	
	public void hacerAnimalada(String eleccion){
		animal.hacerAnimalada(eleccion);
	}

	public void cambiarAnimalCamaleon(Animal pAnimal) {
		this.animal=pAnimal;
	}
	
	public int fuerzaAnimalCarta(){
		return animal.getFuerza();
	}
	
	public String nombreAnimal(){
		return animal.getClass().getSimpleName();
	}
}