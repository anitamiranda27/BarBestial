package packModelo;

import java.util.concurrent.ThreadLocalRandom;

public class Ordenador extends Usuario {

	private static Ordenador mOrdenador;

	private Ordenador() {
		super();
	}

	public static Ordenador getOrdenador() {
		if (mOrdenador==null){
			mOrdenador= new Ordenador();
		}
		return mOrdenador;
	}

	public Carta echarCarta(){
		int pPos = ThreadLocalRandom.current().nextInt(0,mano.getSize());
		return mano.echarCarta(pPos);	
	}
	
	public void jugarOrdenador(){	
		try {
			Carta c = echarCarta();
			cogerCarta();
			setChanged();
			notifyObservers("cartaEchadaOrdenador");
			c.hacerAnimalada(null);			
			Fila.getFila().revisarEstadoFila();
			Juego.getJuego().cambiarTurno();		
		} catch (NoHayCartasEnElMazoException e) {
			Fila.getFila().revisarEstadoFila();
			Juego.getJuego().cambiarTurno();
		}
	}
	
	public void resetear()		//JUNITS
	{
		mOrdenador = null;
	}
}
