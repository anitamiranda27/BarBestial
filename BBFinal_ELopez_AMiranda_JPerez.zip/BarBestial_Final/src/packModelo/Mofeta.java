package packModelo;

public class Mofeta extends Animal {


	public Mofeta() {
		super(1);
	}

	public void hacerAnimalada(String eleccion) {  
		/* Envia a Es lo que hay a todos los animales de las dos especies mas fuertes que hay en la cola 
		 * No repele a otras mofetas
		 */
		
		Fila.getFila().animaladaMofeta();	
	}
}