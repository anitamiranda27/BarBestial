package packModelo;

public class BarBestial {

	private ListaCartas barBestial;
	private static BarBestial mBarBestial;

	private BarBestial() {
		barBestial = new ListaCartas();
	}

	public static BarBestial getBarBestial() {
		if (mBarBestial==null){
			mBarBestial = new BarBestial();
		}
		return mBarBestial;
	}

	public void anadirCarta(Carta pCarta) {
		barBestial.anadirCarta(pCarta);
	}
	
	public int numCartas(String pColor){
		return barBestial.numCartas(pColor);
	}

	public int puntosCartas(String pColor){
		return barBestial.puntosCartas(pColor);
	}
}