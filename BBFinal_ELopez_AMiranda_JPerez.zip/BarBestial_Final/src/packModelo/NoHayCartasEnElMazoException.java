package packModelo;

public class NoHayCartasEnElMazoException extends Exception {
	public  NoHayCartasEnElMazoException(){
		super();
	}
}
