package packModelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ListaCartas {

	private ArrayList<Carta> lista;

	public ListaCartas() {
		lista = new ArrayList<Carta>();
	}

	private Iterator<Carta> getIterador(){
		return lista.iterator();
	}
	
	public void anadirCarta(Carta pCarta) {
		lista.add(pCarta);
	}

	public void eliminarCarta(Carta pCarta) {
		lista.remove(pCarta);
	}
	
	public Carta echarCarta(int pPos){	
		Carta c = lista.get(pPos);
		eliminarCarta(c);
		Fila.getFila().anadirCarta(c);
		return c;
	}

	public Carta cogerCarta(int pPos) throws NoHayCartasEnElMazoException {
		if (estaVacia()){
			throw new NoHayCartasEnElMazoException();
		} else {
			Carta c = lista.get(0);
			eliminarCarta(c);
			return c;
		}
	}
	
	private void enviarBarBestial(int pos1, int pos2){
		BarBestial.getBarBestial().anadirCarta(lista.get(pos1));
		BarBestial.getBarBestial().anadirCarta(lista.get(pos2));
		eliminarCarta(lista.get(pos2));
		eliminarCarta(lista.get(pos1));
	}
	
	private void enviarEsLoQueHay(int pPos){
		EsLoQueHay.getEsLoQueHay().anadirCarta(lista.get(pPos));
		eliminarCarta(lista.get(pPos));	
	}
	
	
	private void eliminarAnimalFila (String pAnimal){
		Iterator<Carta> itr = getIterador();
		Carta c;
		int i = 0;
		boolean salir = false;
		while (itr.hasNext() && !salir){
			c = itr.next();
			if (c.esElMismoAnimal(pAnimal)){
				enviarEsLoQueHay(i);
				eliminarCarta(c);
				salir = true;
			}
			i++;
		}
	}

	public Carta getUnaCarta(int pPos) {
		return lista.get(pPos);
	}
	
	public boolean estaVacia(){
		return lista.isEmpty();
	}

	public int getSize(){
		if (!lista.isEmpty()){
			return lista.size();
		}else {
			return 0;
		}
	}
	
	public void barajar(){
		Collections.shuffle(lista);
	}
	
	public void revisarEstadoFila(){
		
		if (getSize()==5){
			enviarEsLoQueHay(4);
			enviarBarBestial(0,1);		
		}
	}
	
	private boolean puedeAdelantar(Animal pAnimal, int pPos){
		if (pAnimal  instanceof Jirafa){
			return !(lista.get(pPos).mayorFuerza(pAnimal));
		}else {
			if (lista.get(pPos).esElMismoAnimal("Cebra") || lista.get(pPos).mayorFuerza(pAnimal)){
				return false;
			} else {
				return true;
			}
		}
	}
	
	public int numCartas(String pColor){
		Iterator<Carta>  itr = getIterador();
		Carta carta;
		int num = 0 ;
		while(itr.hasNext()){
			carta = itr.next();
			if (carta.colorIgual(pColor)){
				num++;
			}
		}
		return num;
	}
	
	public int puntosCartas(String pColor){
		Iterator<Carta>  itr = getIterador();
		Carta carta;
		int puntos = 0 ;
		while(itr.hasNext()){
			carta = itr.next();
			if (carta.colorIgual(pColor)){
				puntos += carta.fuerzaAnimalCarta();
			}
		}
		return puntos;
	}
	
	private int hayAlgunAnimal(String pAnimal){
		Iterator<Carta>  itr = getIterador();
		Carta carta;
		int i=0;
		while (itr.hasNext()){
			carta = itr.next();
			if (carta.nombreAnimal().equals(pAnimal)){
				i++;
			}
		}
		return i;
	}
	
	private void colocarUltimaCartaEnPosicion(int pPos){	
		if (Fila.getFila().getSize()>0){
			Carta c = lista.get(Fila.getFila().getSize()-1);
			eliminarCarta(c);
			lista.add(pPos, c);
		}
	}
	
	private void colocarAnimalEnPosicion (String pAnimal, int pPos){	
		boolean salir = false;
		int i = 0;
		while(i<getSize() && !salir){
			i++;
			if (lista.get(i).esElMismoAnimal(pAnimal)){
				salir = true;
			}
		}
		Carta c = lista.get(i);
		eliminarCarta(c);
		lista.add(pPos, c);
	}
	
	private String animalMayorFuerza(){
		int fuerza=1;
		String animal = lista.get(0).nombreAnimal();
		Carta c;
		Iterator<Carta> itr = getIterador();
		while(itr.hasNext()){
			 c = itr.next();
			 if (c.fuerzaMayor(fuerza)){
				 fuerza = c.fuerzaAnimalCarta();
				 animal = c.nombreAnimal();
			 }
		}
		return animal;
	}
	
	public void ordenarPorFuerza(){
		lista.sort(new OrdenadoPorFuerza());
	}
	
	public void hacerAnimaladasRecurrente(){
			Carta c;
			int i = getSize()-1;
			while(i>=0){	
				c = lista.get(i);
				if (c.esRecurrente()){
					c.hacerAnimalada(null);
				}
				i--;
			}
	}
	
	public void hacerAnimalada(int pos){		//JUNITS
		lista.get(pos).hacerAnimalada(null);
	}
	
	public int posicionCarta(Animal pAnimal){
		Iterator<Carta> itr = getIterador();
		Carta c;
		boolean salir =false;
		int i=-1;
		while(itr.hasNext() && !salir){
			c = itr.next();
			i++;
			if (c.getAnimal().equals(pAnimal)){
				salir = true;
			}
		}
		return i;
	}
	
	public void animaladaMofeta(){
		
		for (int j=0;j<2;j++){		
			String animal = animalMayorFuerza();
			if (!animal.equals("Mofeta")){
				while (hayAlgunAnimal(animal)>0){
					eliminarAnimalFila(animal);
				}
			}
		}
	}
	
	public void animaladaLeon(){
			
		if (hayAlgunAnimal("Leon")>1){
			enviarEsLoQueHay(getSize()-1);
		} else {
			if (hayAlgunAnimal("Mono")>0){
				eliminarAnimalFila("Mono");
			}
			colocarUltimaCartaEnPosicion(0);
		}
	}
	
	public void animaladaMono(){	
		int numMonos = hayAlgunAnimal("Mono");
		if (numMonos>1){
			if (hayAlgunAnimal("Hipopotamo")>0){
				while (hayAlgunAnimal("Hipopotamo")>0){
					eliminarAnimalFila("Hipopotamo");
				}
			}
			if (hayAlgunAnimal("Cocodrilo")>0){
				while (hayAlgunAnimal("Cocodrilo")>0){
					eliminarAnimalFila("Cocodrilo");
				}
			}
			
			colocarUltimaCartaEnPosicion(0);
			colocarAnimalEnPosicion("Mono", 1);
		}
	}
	
	public void animaladaCocodrilo(Animal pAnimal){
		int pos = posicionCarta(pAnimal)-1; 
		boolean salir = false;
		while (!salir && pos>=0){
			if (puedeAdelantar(pAnimal,pos)){
				enviarEsLoQueHay(pos);
				colocarUltimaCartaEnPosicion(pos);
				pos--;
			} else{
				salir=true;
			}
		}
	}
	
	public void animaladaHipopotamo(Animal pAnimal){
		
		int pos = posicionCarta(pAnimal)-1;		
		boolean salir = false;
		while (!salir && pos>=0){
			if (puedeAdelantar(pAnimal,pos)){
				colocarUltimaCartaEnPosicion(pos);
				pos--;
			} else{
				salir=true;
			}
		}
	}
	
	public void animaladaJirafa(Animal pAnimal){
		int pos = posicionCarta(pAnimal)-1;  
		if (pos>=0){
			if (puedeAdelantar(pAnimal,pos)){
				colocarUltimaCartaEnPosicion(pos);
			}
		}
	}
	
	public void animaladaCamaleon(Animal pAnimal, int pPos){
		if (getSize()>1){
			Carta cCamaleon = getUnaCarta(posicionCarta(pAnimal));
			Animal animalCamaleon = cCamaleon.getAnimal();
			Carta cDisfraz = getUnaCarta(pPos);
			
			cCamaleon.cambiarAnimalCamaleon(cDisfraz.getAnimal());
			cCamaleon.hacerAnimalada(null);
			cCamaleon.cambiarAnimalCamaleon(animalCamaleon);/////////////SI CAMBIA LA CARTA NADA MAS HACER LA ANIMALADA!!!!!!!!!!!!!!////////////
		}
	}
	
	public void animaladaCanguro(int pos){
		if ((getSize()==2 && pos==1) || getSize()>2){
			colocarUltimaCartaEnPosicion((getSize()-1)-pos);
		}
	}
	
	public void animaladaLoro(int pPos){
		enviarEsLoQueHay(pPos);
	}
	
	public void ordenarOrdenInverso(){
		Collections.reverse(lista);
	}
}