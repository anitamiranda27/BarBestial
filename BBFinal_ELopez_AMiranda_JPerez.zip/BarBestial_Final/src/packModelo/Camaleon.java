package packModelo;

import java.util.concurrent.ThreadLocalRandom;

public class Camaleon extends Animal {


	public Camaleon() {
		super(5);
	}

	public void hacerAnimalada(String eleccion) throws IndexOutOfBoundsException{
		/*  Realiza la animalada de otro animal de la cola  y adopta su fuerza durante dicho turno
		 */
		
		int pos=0;
		
		if (eleccion!=null){
			if (eleccion.equals("1")){
				pos = 0;
			} else if (eleccion.equals("2")){
				pos = 1;
			} else if (eleccion.equals("3")){
				pos = 2;
			} else if (eleccion.equals("4")){
				pos = 3;
			} else {
				throw new IndexOutOfBoundsException();
			}
		} else { //Eleccion aleatoria
			pos = ThreadLocalRandom.current().nextInt(0,Fila.getFila().getSize());
		}
	
		Fila.getFila().animaladaCamaleon(this, pos);
	}

}