package packModelo;

import java.util.concurrent.ThreadLocalRandom;

public class Canguro extends Animal {


	public Canguro() {
		super(3);
	}

	public void hacerAnimalada(String eleccion) throws IndexOutOfBoundsException{ 
		/* Salta por encima del ultimo o de los dos ultimos animales de la cola sin importar la fuerza
		 *Los elige el jugador
		 */
		int pos=0;
				
		if (eleccion!=null){ //jugador
			if (eleccion.equals("1")){
				pos = 1;
			} else if (eleccion.equals("2")){
				pos = 2;
			} else {
				throw new IndexOutOfBoundsException();
			}

		} else { //ordenador
			if ((Fila.getFila().getSize()==2)){
				pos = 1;
			} else {
				pos = ThreadLocalRandom.current().nextInt(1,3);
			}
		}
		Fila.getFila().animaladaCanguro(pos);
	}
}