package packModelo;

public class EsLoQueHay {

	private ListaCartas esLoQueHay;
	private static EsLoQueHay mEsLoQueHay;

	private EsLoQueHay() {
		esLoQueHay = new ListaCartas();
	}

	public static EsLoQueHay getEsLoQueHay() {
		if (mEsLoQueHay==null){
			mEsLoQueHay = new EsLoQueHay();
		}
		return mEsLoQueHay;
	}


	public void anadirCarta(Carta pCarta) {
		esLoQueHay.anadirCarta(pCarta);
	}

	public int numCartas(String pColor){	//JUNITS
		return esLoQueHay.numCartas(pColor);
	}
	
	public Carta getUnaCarta(int pPos) {	//JUNITS
		return esLoQueHay.getUnaCarta(pPos);
	}
}