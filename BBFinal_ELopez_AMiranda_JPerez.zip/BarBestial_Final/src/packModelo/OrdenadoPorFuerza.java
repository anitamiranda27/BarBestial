package packModelo;

import java.util.Comparator;

public class OrdenadoPorFuerza  implements Comparator<Carta>{

	@Override
	public int compare(Carta c1, Carta c2) {
		return c2.fuerzaAnimalCarta() - c1.fuerzaAnimalCarta();
	}
		

}
