package packModelo;

public class Cocodrilo extends Animal implements IRecurrente {


	public Cocodrilo() {
		super(10);
	}

	public void hacerAnimalada(String eleccion) {
		/*Se come a todos los que sean mas debiles excepto si es mas fuerte o es una cebra
		 */
		
		Fila.getFila().animaladaCocodrilo(this);
	}

}