package packModelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Observable;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class ListaDatosJugador extends Observable{

	private ArrayList<DatosJugador> lista;
	private static ListaDatosJugador mListaDatosJugador;
	
	
	private ListaDatosJugador()
	{
		lista = new ArrayList<DatosJugador>();
	}
	
	public static ListaDatosJugador getListaDatos()
	{
		if(mListaDatosJugador == null)
		{
			mListaDatosJugador = new ListaDatosJugador();
		}
		return mListaDatosJugador;
	}
	
	private Iterator<DatosJugador> getIterador()
	{
		return lista.iterator();
	}
	
	public boolean comprobarDatos(String pNombre, String pPwd)
	{
		Iterator<DatosJugador> itr = getIterador();
		DatosJugador d;
		boolean enc = false;
		while(itr.hasNext() && !enc)
		{
			d = itr.next();
			enc = d.datosCorrectos(pNombre,pPwd);
		}
		return enc;
	}
	
	private boolean comprobarNombreUsuario(String pNombre)
	{
		Iterator<DatosJugador> itr = getIterador();
		DatosJugador d;
		boolean enc = false;
		while(itr.hasNext() && !enc)
		{
			d = itr.next();
			enc = d.nombreCorrecto(pNombre);
		}
		return enc;
	}
	
	public boolean registrarUsuario(String pNombre, String pPwd1, String pPwd2){
		if (comprobarNombreUsuario(pNombre)){
			setChanged();
			notifyObservers("existeUsuario");
		} else {
			if (pPwd1.equals(pPwd2)){
				DatosJugador jug = new DatosJugador(pNombre,pPwd1);
				lista.add(jug);
				return true;
			} else {
				setChanged();
				notifyObservers("contrasenasDistintas");
			}
		}
		return false;
	}
	
	public void sumarPuntos(String pNombre)
	{
		Iterator<DatosJugador> itr = getIterador();
		DatosJugador d = null;
		boolean enc = false;
		while(itr.hasNext() && !enc)
		{
			d = itr.next();
			enc = d.nombreCorrecto(pNombre);
		}
		d.sumarPunto();
	}
	
	public void cargarDatos() throws IOException, ClassNotFoundException
	{
		InputStream input = getClass().getResourceAsStream("/ListaDatos.dat");
		ObjectInputStream ois = new ObjectInputStream(input);
		lista = (ArrayList<DatosJugador>) ois.readObject();
		ois.close();		
		
	}
	
	public void ordenar()
	{
		Collections.sort(lista,new OrdenadoPorPuntuacion());
	}
	
	public ArrayList<DatosJugador> getLista()
	{
		return lista;
	}
	
	public JSONArray enviarDatosRanking()
	{
		//Generamos un JSONArray con los atributos
		JSONArray datos = new JSONArray();
		
		Iterator<DatosJugador> itr = getIterador();
		DatosJugador d = null;
		while(itr.hasNext())
		{
			d = itr.next();
			
			JSONObject usuario = new JSONObject();
			usuario.put("usuario", d.getNombre());
			datos.add(usuario);
			
			JSONObject puntuacion = new JSONObject();
			usuario.put("puntuacion", d.getPuntuacion());
			datos.add(puntuacion);
			
		}
		return datos;	
		
	}

	public void resetear() {
		mListaDatosJugador = null;
		
	}
}
