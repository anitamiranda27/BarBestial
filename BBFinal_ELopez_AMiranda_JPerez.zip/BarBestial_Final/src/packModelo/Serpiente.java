package packModelo;


public class Serpiente extends Animal {


	public Serpiente() {
		super(9);
	}

	public void hacerAnimalada(String eleccion) {
		/* Se ponen en orden segun su fuerza todos los animales
		 * Si son de la misma especie no se cambia el orden 
		 */
		
		Fila.getFila().ordenarPorFuerza();	
	}

}