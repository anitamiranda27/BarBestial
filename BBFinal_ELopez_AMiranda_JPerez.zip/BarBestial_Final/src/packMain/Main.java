package packMain;

import java.io.IOException;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import packModelo.Juego;
import packModelo.ListaDatosJugador;
import packVista.F00Principal;


public class Main {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException, IOException {
		UIManager.setLookAndFeel("com.jtattoo.plaf.bernstein.BernsteinLookAndFeel");	
		F00Principal frame = new F00Principal();
		frame.setVisible(true);
		Juego.getJuego().inicializarJuego();
	}

}
