package packPruebas;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import packModelo.Animal;
import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Juego;
import packModelo.Jugador;
import packModelo.ListaCartas;
import packModelo.NoHayCartasEnElMazoException;
import packModelo.Ordenador;
import packModelo.Usuario;

public class UsuarioTest {

	@Test
	public void testUsuario() {
		assertNotNull(Jugador.getJugador());
		assertNotNull(Ordenador.getOrdenador());

	}

	@Test
	public void testCogerCarta() {
		
		Jugador.getJugador().repartirCartas("Azul");
		assertTrue(Jugador.getJugador().echarCarta(0).colorIgual("Azul"));
	
	}

	@Test
	public void testRepartirCartas() throws ClassNotFoundException, IOException {
		
		Jugador.getJugador().repartirCartas("Azul");
		Ordenador.getOrdenador().repartirCartas("Verde");
		
		assertEquals(4,Jugador.getJugador().getManoSize());
		assertEquals(4,Ordenador.getOrdenador().getManoSize());
	}

	@Test
	public void testTieneCartas() throws ClassNotFoundException, IOException {
		Juego.getJuego().resetear();
		
		assertTrue(Jugador.getJugador().tieneCartas());	
		assertTrue(Ordenador.getOrdenador().tieneCartas());
	}
	
	@Test
	public void TestManoLlena() throws ClassNotFoundException, IOException
	{
		Jugador.getJugador().resetear();
		Ordenador.getOrdenador().resetear();
		
		Juego.getJuego().inicializarJuego();
		
		assertTrue(Jugador.getJugador().manoLlena());
		assertTrue(Ordenador.getOrdenador().manoLlena());
	}
	
	@Test
	public void TestGetManoSize() throws ClassNotFoundException, IOException 
	{
		Jugador.getJugador().resetear();
		Ordenador.getOrdenador().resetear();
		
		assertEquals(0,Jugador.getJugador().getManoSize());
		assertEquals(0,Ordenador.getOrdenador().getManoSize());
		
		Juego.getJuego().inicializarJuego();
		
		assertEquals(4,Jugador.getJugador().getManoSize());
		assertEquals(4,Ordenador.getOrdenador().getManoSize());
	}
	
	@Test
	public void testMazoVacio() throws ClassNotFoundException, IOException {
		Juego.getJuego().resetear();
		
		assertTrue(Jugador.getJugador().mazoVacio());
		assertTrue(Ordenador.getOrdenador().mazoVacio());
		
	}

}
