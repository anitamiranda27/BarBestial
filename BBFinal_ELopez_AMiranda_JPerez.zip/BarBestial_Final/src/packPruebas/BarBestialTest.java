package packPruebas;

import static org.junit.Assert.*;
import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.BarBestial;
import packModelo.Carta;
import packModelo.ListaCartas;

public class BarBestialTest {

	@Test
	public void testGetBarBestial() {
		assertNotNull(BarBestial.getBarBestial());
	}

	@Test
	public void testAnadirCarta() {
		Carta c = new Carta("Azul" , AnimalFactory.getAnimalFactory().crearAnimal(4));
		BarBestial.getBarBestial().anadirCarta(c);
		
		assertEquals(1,BarBestial.getBarBestial().numCartas("Azul"));
	}
	
	@Test
	public void testNumCartas() {
		Carta c = new Carta("Rojo" , AnimalFactory.getAnimalFactory().crearAnimal(4));
		BarBestial.getBarBestial().anadirCarta(c);
		assertEquals(1,BarBestial.getBarBestial().numCartas("Rojo")); 
	}
	
	public void TestPuntosCartas(){
		Carta c = new Carta("Azul" , AnimalFactory.getAnimalFactory().crearAnimal(4));
		BarBestial.getBarBestial().anadirCarta(c);
		assertNotNull(BarBestial.getBarBestial().puntosCartas("Azul"));
		assertEquals(0,BarBestial.getBarBestial().puntosCartas("Verde"));
	}
	
}
