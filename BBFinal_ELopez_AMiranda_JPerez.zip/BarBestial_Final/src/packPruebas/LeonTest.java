package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.EsLoQueHay;
import packModelo.Fila;
import packModelo.Leon;

public class LeonTest {

	@Test
	public void testHacerAnimalada()
	{
		/*  Si hay un leon en la cola, se va a EsLoQueHay
		 * Si no hay ningun leon en la cola, manda a todos los monos a EsloQueHay 
		 * y se coloca el primero en la fila
		 */
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(4));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(12));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(12));
		Fila.getFila().anadirCarta(c3);
		
		c3.hacerAnimalada(null); 
		assertEquals(1, EsLoQueHay.getEsLoQueHay().numCartas("Azul")); //Hay un leon en la cola, se va a EsLoQueHay
		
		Fila.getFila().eliminarCarta(c2);
		Fila.getFila().anadirCarta(c3);
		c3.hacerAnimalada(null); 
		assertEquals(2, EsLoQueHay.getEsLoQueHay().numCartas("Azul")); //Ahora no hay mas leones, manda los monos a EsLoQueHay 
		assertEquals(0, Fila.getFila().posicionCarta(c3.getAnimal())); //Se coloca el primero
	}

	@Test
	public void testLeon() {
		Leon l = new Leon();
		assertNotNull(l);
		assertEquals(12, l.getFuerza());
	}

}
