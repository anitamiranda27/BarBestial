package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Fila;
import packModelo.Serpiente;

public class SerpienteTest {

	@Test
public void testHacerAnimalada() {
		
		//Cartas Desordenadas
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(4));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(9));
		Fila.getFila().anadirCarta(c3);
		
		/* Se ponen en orden segun su fuerza todos los animales
		 * Si son de la misma especie no se cambia el orden 
		 */
		c3.hacerAnimalada(null);
		
		//Cartas Ordenadas
		assertEquals(0,Fila.getFila().posicionCarta(c3.getAnimal()));
		assertEquals(1,Fila.getFila().posicionCarta(c2.getAnimal()));
		assertEquals(2,Fila.getFila().posicionCarta(c.getAnimal()));
		assertEquals(3,Fila.getFila().posicionCarta(c1.getAnimal()));
	}

	@Test
	public void testSerpiente() {
		Serpiente s = new Serpiente();
		assertNotNull(s);
		assertEquals(9, s.getFuerza());
	}

}
