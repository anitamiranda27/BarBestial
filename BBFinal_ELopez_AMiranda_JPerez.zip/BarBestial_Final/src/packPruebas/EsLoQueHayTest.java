package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.EsLoQueHay;

public class EsLoQueHayTest {

	@Test
	public void testGetEsLoQueHay() {
		assertNotNull(EsLoQueHay.getEsLoQueHay());
	}

	@Test
	public void testAnadirCarta() {
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		
		assertEquals(0, EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
		
		EsLoQueHay.getEsLoQueHay().anadirCarta(c);
		
		assertEquals(1,EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
		
	}

	public void numCartas() {
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		
		EsLoQueHay.getEsLoQueHay().anadirCarta(c);
		
		assertEquals(1,EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
		
	}

	public void testgetUnaCarta() {
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		
		assertEquals(0, EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
		
		EsLoQueHay.getEsLoQueHay().anadirCarta(c);
		
		assertEquals(c,EsLoQueHay.getEsLoQueHay().getUnaCarta(1));
		
	}

}
