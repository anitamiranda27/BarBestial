package packPruebas;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import packModelo.DatosJugador;
import packModelo.ListaDatosJugador;

public class ListaDatosJugadorTest {

	@Test
	public void testGetListaDatos() {
		assertNotNull(ListaDatosJugador.getListaDatos());
	}

	@Test
	public void testComprobarDatos() {

		ListaDatosJugador.getListaDatos().resetear();
		ListaDatosJugador.getListaDatos().registrarUsuario("a", "pa", "pa");
		assertTrue(ListaDatosJugador.getListaDatos().comprobarDatos("a", "pa"));
		assertFalse(ListaDatosJugador.getListaDatos().comprobarDatos("ad", "pa"));
		assertFalse(ListaDatosJugador.getListaDatos().comprobarDatos("a", "p"));
		assertFalse(ListaDatosJugador.getListaDatos().comprobarDatos("as", "ps"));
	}

	@Test
	public void testRegistrarUsuario() {

		ListaDatosJugador.getListaDatos().resetear();
		ListaDatosJugador.getListaDatos().registrarUsuario("3", "a", "b");
		assertFalse(ListaDatosJugador.getListaDatos().comprobarDatos("3", "b"));
		ListaDatosJugador.getListaDatos().registrarUsuario("3", "a", "a");
		assertTrue(ListaDatosJugador.getListaDatos().comprobarDatos("3", "a"));
	}

	@Test
	public void testSumarPuntos() {

		ListaDatosJugador.getListaDatos().resetear();
		ListaDatosJugador.getListaDatos().getLista().add(new DatosJugador("a", "b"));
		ListaDatosJugador.getListaDatos().sumarPuntos("a");
		assertEquals(1,ListaDatosJugador.getListaDatos().getLista().get(0).getPuntuacion());
	}

	@Test
	public void testCargarDatos() {
		assertTrue(true);
	}

	@Test
	public void testOrdenar() {
		ListaDatosJugador.getListaDatos().resetear();
		ListaDatosJugador.getListaDatos().getLista().add(new DatosJugador("a", "b"));
		ListaDatosJugador.getListaDatos().sumarPuntos("a");
		ListaDatosJugador.getListaDatos().getLista().add(new DatosJugador("c", "d"));
		ListaDatosJugador.getListaDatos().sumarPuntos("c");
		ListaDatosJugador.getListaDatos().sumarPuntos("c");
		ListaDatosJugador.getListaDatos().ordenar();
		assertEquals(2,ListaDatosJugador.getListaDatos().getLista().get(0).getPuntuacion());
		assertEquals(1,ListaDatosJugador.getListaDatos().getLista().get(1).getPuntuacion());


	}

	@Test
	public void testGetLista() {
		assertNotNull(ListaDatosJugador.getListaDatos().getLista());
	}

	@Test
	public void testEnviarDatosRanking() {

		ListaDatosJugador.getListaDatos().resetear();
		ListaDatosJugador.getListaDatos().getLista().add(new DatosJugador("a", "b"));
		ListaDatosJugador.getListaDatos().sumarPuntos("a");
		ListaDatosJugador.getListaDatos().getLista().add(new DatosJugador("c", "d"));
		ListaDatosJugador.getListaDatos().sumarPuntos("c");
		ListaDatosJugador.getListaDatos().sumarPuntos("c");
		assertNotNull(ListaDatosJugador.getListaDatos().enviarDatosRanking());
	}

}
