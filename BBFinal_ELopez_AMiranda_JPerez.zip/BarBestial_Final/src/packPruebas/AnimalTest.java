package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.Animal;
import packModelo.Camaleon;
import packModelo.Mofeta;

public class AnimalTest {

	@Test
	public void testAnimal() {
		Animal a = new Mofeta();
		assertNotNull(a);
	}


	@Test
	public void testGetFuerza() {
		Animal a = new Mofeta();
		assertTrue(a.getFuerza()==1);
	}

	@Test
	public void testMayorFuerza() {
		Animal a = new Mofeta();
		Animal b = new Camaleon();
		assertTrue(b.mayorfuerza(a));
	}

	public void testFuerzaMayor() {
		Animal b = new Camaleon();
		assertTrue(b.fuerzaMayor(1));
	}

}
