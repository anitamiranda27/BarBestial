package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.Animal;
import packModelo.AnimalFactory;

public class AnimalFactoryTest {

	@Test
	public void testGetAnimalFactory() {
		assertNotNull(AnimalFactory.getAnimalFactory());
	}

	@Test
	public void testCrearAnimal() {
		Animal mofeta = AnimalFactory.getAnimalFactory().crearAnimal(1);
		Animal loro = AnimalFactory.getAnimalFactory().crearAnimal(2);
		Animal canguro = AnimalFactory.getAnimalFactory().crearAnimal(3);

		assertTrue(mofeta.getFuerza()==1 && loro.getFuerza()==2 && canguro.getFuerza()==3);
		
	}

}
