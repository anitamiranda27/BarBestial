package packPruebas;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.BarBestial;
import packModelo.Carta;
import packModelo.EsLoQueHay;
import packModelo.Fila;
import packModelo.Hipopotamo;
import packModelo.Jirafa;
import packModelo.Juego;
import packModelo.Jugador;
import packModelo.Leon;
import packModelo.ListaCartas;
import packModelo.Loro;
import packModelo.Mofeta;
import packModelo.NoHayCartasEnElMazoException;

public class ListaCartasTest {

	@Test
	public void testListaCartas() {
		ListaCartas l = new ListaCartas();
		assertNotNull(l);
}

	@Test
	public void testAnadirCarta() {
		ListaCartas l = new ListaCartas();
		l.anadirCarta(new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1)));
		assertTrue(!l.estaVacia());
	}

	@Test
	public void testEliminarCarta() {
		ListaCartas l = new ListaCartas();
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		l.anadirCarta(c);
		l.eliminarCarta(c);
		l.eliminarCarta(c);   //PARA PROBAR QUE SI NO ESTA LA CARTA NO SE ROMPE
		assertTrue(l.estaVacia());
	}

	@Test
	public void testGetUnaCarta() {
		ListaCartas l = new ListaCartas();
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		l.anadirCarta(c);
		assertEquals(c, l.getUnaCarta(0));
		l.eliminarCarta(c);
		
	}
	
	@Test
	public void testEcharCarta() {
		ListaCartas l = new ListaCartas();
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		l.anadirCarta(c);
		Fila.getFila().resetear();
		l.echarCarta(0);
		assertTrue(Fila.getFila().getSize()==1);
	}

	
	@Test
	public void testCogerCarta() {
		ListaCartas l = new ListaCartas();
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		l.anadirCarta(c);
		Carta d = null;
		try {
			d= l.cogerCarta(0);
		} catch (NoHayCartasEnElMazoException e) {
			e.printStackTrace();
		}
		assertTrue(l.getSize()==0 && d.equals(c));
	}


	
	@Test
	public void testEstaVacia() {
		ListaCartas l = new ListaCartas();
		assertTrue(l.estaVacia());
		l.anadirCarta(new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1)));
		assertTrue(!l.estaVacia());
		
	}


	@Test
	public void testGetSize() {
		ListaCartas l = new ListaCartas();
		assertTrue(l.getSize()==0);
		l.anadirCarta(new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1)));
		assertTrue(l.getSize()==1);
		}

	@Test
	public void testBarajar() {
		assertTrue(true); //metodo propio de java.
	}

	
	@Test
	public void testRevisarEstadoFila() {
		Carta c = new Carta("Azul", new Mofeta());
		ListaCartas l = new ListaCartas();
		l.anadirCarta(c);
		l.anadirCarta(c);
		l.anadirCarta(c);
		l.anadirCarta(c);
		Juego.getJuego().resetear();
		l.revisarEstadoFila();
		assertEquals(0,BarBestial.getBarBestial().numCartas("Azul"));
		assertEquals(0,EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
		l.anadirCarta(c);
		l.revisarEstadoFila();
		assertEquals(2, BarBestial.getBarBestial().numCartas("Azul"));
		assertEquals(1, EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
		
		
	}
	
	@Test
	public void testNumCartas() 
	{
		assertEquals(2, BarBestial.getBarBestial().numCartas("Azul"));
		assertEquals(1, EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
	}
	
	@Test
	public void testPuntosCartas() 
	{
		Carta c = new Carta("Azul",new Mofeta());
		Carta d = new Carta("Azul",new Leon());
		Carta e = new Carta("Azul",new Hipopotamo());
		
		ListaCartas l = new ListaCartas();
		l.anadirCarta(d);
		l.anadirCarta(c);
		l.anadirCarta(e);
		
		assertEquals(24,l.puntosCartas("Azul"));

	}
	
	@Test
	public void testOrdenarPorFuerza() 
	{
		Carta c = new Carta("Azul",new Mofeta());
		Carta d = new Carta("Azul",new Leon());
		Carta e = new Carta("Azul",new Hipopotamo());
		
		ListaCartas l = new ListaCartas();
		l.anadirCarta(d);
		l.anadirCarta(c);
		l.anadirCarta(e);
		
		l.ordenarPorFuerza();
		
		assertEquals(d,l.getUnaCarta(0));
		assertEquals(e,l.getUnaCarta(1));
		assertEquals(c,l.getUnaCarta(2));
	}
	
	@Test
	public void testOrdenarOrdenInverso() 
	{
		Carta c = new Carta("Azul",new Mofeta());
		Carta d = new Carta("Azul",new Leon());
		Carta e = new Carta("Azul",new Hipopotamo());
		
		ListaCartas l = new ListaCartas();
		l.anadirCarta(d);
		l.anadirCarta(c);
		l.anadirCarta(e);
		
		assertEquals(d,l.getUnaCarta(0));
		assertEquals(c,l.getUnaCarta(1));
		assertEquals(e,l.getUnaCarta(2));
		
		l.ordenarOrdenInverso();
		
		assertEquals(e,l.getUnaCarta(0));
		assertEquals(c,l.getUnaCarta(1));
		assertEquals(d,l.getUnaCarta(2));
		
	}
	
	public void testPosicionCarta() 
	{
		Carta c = new Carta("Azul",new Mofeta());
		Carta d = new Carta("Azul",new Leon());
		Carta e = new Carta("Azul",new Hipopotamo());
		
		ListaCartas l = new ListaCartas();
		l.anadirCarta(d);
		l.anadirCarta(c);
		l.anadirCarta(e);
		
		assertEquals(0,l.posicionCarta(d.getAnimal()));
		assertEquals(1,l.posicionCarta(c.getAnimal()));
		assertEquals(2,l.posicionCarta(e.getAnimal()));

	}
	
	//Las pruebas de las animaladas estan en sus respectivas clases
}
