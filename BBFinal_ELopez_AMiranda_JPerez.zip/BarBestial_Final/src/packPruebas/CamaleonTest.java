package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Camaleon;
import packModelo.Carta;
import packModelo.Fila;

public class CamaleonTest {

	@Test
	public void testHacerAnimalada() 
	{ 
		/*  Realiza la animalada de otro animal de la cola  y adopta su fuerza durante dicho turno
		 */
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(9));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(5));
		Fila.getFila().anadirCarta(c3);
		
		c3.hacerAnimalada("1"); //Adopta la fuerza de la Serpiente y realiza su animalada
		
		//Animalada Serpiente: Cartas ordenadas por fuerza
		assertEquals(0,Fila.getFila().posicionCarta(c1.getAnimal()));
		assertEquals(1,Fila.getFila().posicionCarta(c.getAnimal()));
		assertEquals(2,Fila.getFila().posicionCarta(c3.getAnimal()));
		assertEquals(3,Fila.getFila().posicionCarta(c2.getAnimal()));
	
		
		
	}

	@Test
	public void testCamaleon() {
		Camaleon c = new Camaleon();
		assertNotNull(c);
		assertEquals(5,c.getFuerza());
	}

}
