package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.EsLoQueHay;
import packModelo.Fila;
import packModelo.Mono;

public class MonoTest {

	@Test
	public void testHacerAnimalada() //No esta implementado aun
	{
		/* Si solo hay un mono no hace nada
		 * Si hay mas de uno envian a EsLoQueHay a los hipopotamos y a los cocodrilos
		 * El mono que ha jugado en dicho turno se cuela delante de todos colocandose el primero en la cola
		 * detras de el se colocan los demas mono de la cola en orden inverso
		 */
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(9));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(4));
		Fila.getFila().anadirCarta(c3);
		
		c3.hacerAnimalada(null); //Solo hay un mono, por lo tanto no hace nada
		
		Carta c4 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(4));
		Fila.getFila().anadirCarta(c4);
		
		c4.hacerAnimalada(null);  
		assertEquals(1,EsLoQueHay.getEsLoQueHay().numCartas("Azul")); //Envia c1 a EsLoQueHay porque es un Cocodrilo
		assertEquals(0,Fila.getFila().posicionCarta(c4.getAnimal())); //Se coloca el primero
		assertEquals(1,Fila.getFila().posicionCarta(c3.getAnimal())); //Detras se colocan el resto de monos
		
	}

	@Test
	public void testMono() {
		Mono m = new Mono();
		assertNotNull(m);
		assertEquals(4, m.getFuerza());
	}

}
