package packPruebas;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.BarBestial;
import packModelo.Carta;
import packModelo.Juego;
import packModelo.Jugador;
import packModelo.Mofeta;
import packModelo.NoHayCartasEnElMazoException;
import packModelo.Ordenador;

public class JuegoTest {

	@Test
	public void testGetJuego() {
		assertNotNull(Juego.getJuego());
	}

	@Test
	public void testInicializarJuego() throws ClassNotFoundException, IOException {
		Juego.getJuego().inicializarJuego();
		
		assertTrue(Jugador.getJugador().getManoSize()==4);
		assertTrue(Ordenador.getOrdenador().getManoSize()==4);
		
	}

	@Test
	public void testFinJuego()
	{
		Jugador.getJugador().echarCarta(3);
		Jugador.getJugador().echarCarta(2);
		Jugador.getJugador().echarCarta(1);
		Jugador.getJugador().echarCarta(0);
		
		Ordenador.getOrdenador().echarCarta();
		Ordenador.getOrdenador().echarCarta();
		Ordenador.getOrdenador().echarCarta();
		Ordenador.getOrdenador().echarCarta();
		
		assertTrue(Juego.getJuego().finJuego());
	}
	
	
	@Test
	public void testCambiarTurno() 
	{
		Juego.getJuego().resetear();
		boolean a= Juego.getJuego().esTurnoJugador();
		Juego.getJuego().cambiarTurno();
		boolean b= Juego.getJuego().esTurnoJugador();
		assertNotEquals(a,b);
				
	}

	@Test
	public void testGanador() 
	{
		try {
			Juego.getJuego().inicializarJuego();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		Jugador.getJugador().setNombre("A");
		Jugador.getJugador().echarCarta(3);
		Jugador.getJugador().echarCarta(2);
		Jugador.getJugador().echarCarta(1);
		Jugador.getJugador().echarCarta(0);
		
		Ordenador.getOrdenador().echarCarta();
		Ordenador.getOrdenador().echarCarta();
		Ordenador.getOrdenador().echarCarta();
		Ordenador.getOrdenador().echarCarta();
		
		BarBestial.getBarBestial().anadirCarta(new Carta("Azul",new Mofeta()));
		assertEquals("A",Juego.getJuego().ganador());
	}
	

}
