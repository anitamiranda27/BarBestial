package packPruebas;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import packModelo.Fila;
import packModelo.Juego;
import packModelo.Jugador;
import packModelo.Ordenador;

public class OrdenadorTest {

	@Test
	public void testGetOrdenador() {
		assertNotNull(Ordenador.getOrdenador());
	}

	@Test
	public void testEcharCarta() throws ClassNotFoundException, IOException {
		Juego.getJuego().inicializarJuego();
		Ordenador.getOrdenador().echarCarta();
		assertTrue(Fila.getFila().getSize()!=0);
	}

	@Test
	public void testJugarOrdenador() {
		//Comprobar en el juego que hace todo lo necesario.
	}

}
