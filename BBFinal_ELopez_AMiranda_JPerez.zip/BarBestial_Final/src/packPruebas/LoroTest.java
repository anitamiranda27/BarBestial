package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.EsLoQueHay;
import packModelo.Fila;
import packModelo.Loro;

public class LoroTest {

	@Test
	public void testHacerAnimalada() //No esta implementado aun
	{
		/* El loro ahuyenta a un animal de la cola y lo manda a EsLoQueHay
		 * Dicho animal lo elige el jugador 
		*/
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(2));
		Fila.getFila().anadirCarta(c3);
		
		c3.hacerAnimalada("1"); //El jugador elige la carta en la posicion 1 (El Cocodrilo) que se manda a EsLoQueHay
		
		assertEquals(1, EsLoQueHay.getEsLoQueHay().numCartas("Azul"));
		
	}

	@Test
	public void testLoro() {
		Loro l = new Loro();
		assertNotNull(l);
		assertEquals(2, l.getFuerza());
	}

}
