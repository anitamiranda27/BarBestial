package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import java.awt.Image;

import javax.swing.ImageIcon;


import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Leon;
import packModelo.Mofeta;

public class CartaTest {

	@Test
	public void testCarta() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		assertNotNull(c);
	}

	@Test
	public void testGetImagen() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		assertNotNull(c.getImagen());
	}
	
	@Test
	public void testGetAnimal() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		
		assertNotNull(c.getAnimal());
	}

	@Test
	public void testColorIgual() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		assertTrue(c.colorIgual("Azul"));
		assertFalse(c.colorIgual("Verde"));
	}
	
	@Test
	public void testAsignarImagenCarta() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		assertNotNull(c.getImagen());

        
	}
	
	@Test
	public void testMayorFuerza() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(2));
		assertTrue(c.mayorFuerza(new Mofeta()));
		assertFalse(c.mayorFuerza(new Leon()));
		        
	}
	
	@Test
	public void testEsElMismoAnimal() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));	
		assertTrue(c.esElMismoAnimal("Mofeta"));
		assertFalse(c.esElMismoAnimal("Leon"));
	}
	
	@Test
	public void testFuerzaMayor() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(2));
		assertTrue(c.fuerzaMayor(1));
		assertFalse(c.fuerzaMayor(3));    
	}
	
	@Test
	public void testEsRecurrente() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(7));
		assertTrue(c.esRecurrente());   
	}
	
	@Test
	public void testCambiarAnimal() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(2));
		c.cambiarAnimalCamaleon(new Mofeta());
		assertTrue(c.esElMismoAnimal("Mofeta"));
		        
	}
	
	@Test
	public void testFuerzaAnimalCarta() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(2));
		assertTrue(c.fuerzaAnimalCarta()==2);
	}
	
	@Test
	public void testNombreAnimal() {
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		assertTrue(c.nombreAnimal().equals("Mofeta"));
	}
}
