package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Fila;
import packModelo.Jirafa;

public class JirafaTest {

	@Test
	public void testHacerAnimalada()
	{
		/* Se cuela delante de un animal mas debil
		 * Solo se puede colar delante de un animal por turno
		 */
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(8));
		Fila.getFila().anadirCarta(c3);
		
		assertEquals(3, Fila.getFila().posicionCarta(c3.getAnimal())); //Antes de hacer la animalada esta en la pos = 3
		c3.hacerAnimalada(null);
		assertEquals(2, Fila.getFila().posicionCarta(c3.getAnimal())); //Se cuela delante de la Mofeta, es decir en la pos = 2 
																	   // porque es un animal mas debil
		
	}

	@Test
	public void testJirafa() {
		Jirafa j = new Jirafa();
		assertNotNull(j);
	}

	@Test
	public void testHacerAnimaladaRecurrente() //No esta implementado aun
	{
		
	}

}
