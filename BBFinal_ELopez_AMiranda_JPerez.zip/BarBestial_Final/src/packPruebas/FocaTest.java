package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Fila;
import packModelo.Foca;

public class FocaTest {

	@Test
	public void testHacerAnimalada() //No esta implementado aun
	{
		/* Cambia de sitio la carta de Es Lo Que Hay con la de la Puerta del cielo
		 */
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(6));
		Fila.getFila().anadirCarta(c3);
		
		
		c3.hacerAnimalada(null);
		assertEquals(0, Fila.getFila().posicionCarta(c3.getAnimal())); //El primer animal ahora es la Foca porque se ha invertido la cola
		
	}

	@Test
	public void testFoca() {
		Foca f = new Foca();
		assertNotNull(f);
		assertEquals(6, f.getFuerza());
	}

}
