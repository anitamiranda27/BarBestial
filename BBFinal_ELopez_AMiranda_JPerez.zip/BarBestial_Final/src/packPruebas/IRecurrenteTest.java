package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

public class IRecurrenteTest {

	@Test
	public void testHacerAnimaladaRecurrente() //No esta implementado aun
	{
		
	}

}
