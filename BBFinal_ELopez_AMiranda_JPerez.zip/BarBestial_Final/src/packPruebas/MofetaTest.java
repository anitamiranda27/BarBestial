package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.EsLoQueHay;
import packModelo.Fila;
import packModelo.Mofeta;

public class MofetaTest {

	@Test
	public void testHacerAnimalada()
	{
		/* Envia a Es lo que hay a todos los animales de las dos especies mas fuertes que hay en la cola 
		 * No repele a otras mofetas
		 */
				
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(12));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(6));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c3);

		c3.hacerAnimalada(null);
		assertEquals(2, EsLoQueHay.getEsLoQueHay().numCartas("Azul")); //Las dos especies mas fuertes son el Leon (c) y el Cocodrilo (c1)
		assertEquals(c,EsLoQueHay.getEsLoQueHay().getUnaCarta(0));	   //Por lo tanto, se envian a Es Lo Que Hay
		assertEquals(c2,EsLoQueHay.getEsLoQueHay().getUnaCarta(1));
	}

	@Test
	public void testMofeta() {
		Mofeta m = new Mofeta();
		assertNotNull(m);
		assertEquals(1,m.getFuerza());
	}

}
