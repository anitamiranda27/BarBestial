package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.Cebra;

public class CebraTest {

	@Test
	public void testHacerAnimalada() 
	{
		/* No pueden ser adelantadas por los hipopotamos ni por los cocodrilos
		 * tampoco pueden ser comidas. Su animalada es PASIVA
		 */
		
	}

	@Test
	public void testCebra() {
		
		Cebra c = new Cebra();
		assertNotNull(c);
	}

	@Test
	public void testHacerAnimaladaRecurrente() 
	{
		
	}

}
