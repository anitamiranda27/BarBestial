package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Cocodrilo;
import packModelo.Fila;

public class CocodriloTest {

	@Test
	public void testHacerAnimalada()
	{
		/*Se come a todos los que sean mas debiles excepto si es mas fuerte o es una cebra
		 */
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(12));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(7));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c3);
		
		c3.hacerAnimalada(null); //Se deberia quedar en la pos = 2 ya que no puede comerse al Leon ni a la Cebra pero si a la Mofeta
		assertEquals(2, Fila.getFila().posicionCarta(c3.getAnimal()));
		
	}

	@Test
	public void testCocodrilo() 
	{
		Cocodrilo c = new Cocodrilo();
		assertNotNull(c);
	}

	@Test
	public void testHacerAnimaladaRecurrente() //No esta implementado aun
	{
		
	}

}
