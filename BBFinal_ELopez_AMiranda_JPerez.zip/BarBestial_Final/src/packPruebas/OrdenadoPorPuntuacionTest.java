package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.DatosJugador;
import packModelo.ListaDatosJugador;
import packModelo.OrdenadoPorPuntuacion;

public class OrdenadoPorPuntuacionTest {

	@Test
	public void testCompare() {
		ListaDatosJugador.getListaDatos().resetear();
		ListaDatosJugador.getListaDatos().getLista().add(new DatosJugador("a", "b"));
		ListaDatosJugador.getListaDatos().sumarPuntos("a");
		ListaDatosJugador.getListaDatos().getLista().add(new DatosJugador("c", "d"));
		ListaDatosJugador.getListaDatos().sumarPuntos("c");
		ListaDatosJugador.getListaDatos().sumarPuntos("c");
		ListaDatosJugador.getListaDatos().ordenar();
		OrdenadoPorPuntuacion ordenar = new OrdenadoPorPuntuacion();
		assertEquals(-1,ordenar.compare(ListaDatosJugador.getListaDatos().getLista().get(0), ListaDatosJugador.getListaDatos().getLista().get(1)));
		assertEquals(0,ordenar.compare(ListaDatosJugador.getListaDatos().getLista().get(0), ListaDatosJugador.getListaDatos().getLista().get(0)));
		assertEquals(1,ordenar.compare(ListaDatosJugador.getListaDatos().getLista().get(1), ListaDatosJugador.getListaDatos().getLista().get(0)));
	}

}
