package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Fila;
import packModelo.Hipopotamo;

public class HipopotamoTest {

	@Test
	public void testHacerAnimalada() 
	{
		/* Pasa por delante de todos excepto de los de su propia especie,
		 * los leones o las cebras
		 */
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(12));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(7));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(11));
		Fila.getFila().anadirCarta(c3);
		
		c3.hacerAnimalada(null); //Deberia pasar de la pos = 3 a las pos = 2 porque pasa a la Mofeta pero no a la cebra ni al leon
		assertEquals(2, Fila.getFila().posicionCarta(c3.getAnimal()));
	}

	@Test
	public void testHipopotamo() 
	{
		Hipopotamo h = new Hipopotamo();
		assertNotNull(h);
	}

	@Test
	public void testHacerAnimaladaRecurrente() //No esta implementado aun
	{
		
	}

}
