package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.BarBestial;
import packModelo.Carta;
import packModelo.EsLoQueHay;
import packModelo.Fila;
import packModelo.Loro;
import packModelo.Mofeta;

public class FilaTest {

	@Test
	public void testHacerAnimaladasRecurrente() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(12));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(7));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(11));
		Fila.getFila().anadirCarta(c3);
		
		Fila.getFila().hacerAnimaladasRecurrente(); //Hay un animal recurrente que es el Hipopotamo por lo que realizara su animalada
		
		/* Pasa por delante de todos excepto de los de su propia especie,
		 * los leones o las cebras */		
		
		assertEquals(2,Fila.getFila().posicionCarta(c3.getAnimal()));
	}

	@Test
	public void testHacerAnimalada() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(4));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(9));
		Fila.getFila().anadirCarta(c3);
		
		Fila.getFila().hacerAnimalada(3); 
		//Ejecuta la animalada de la carta en la posicion 3, es decir la Serpiente.
		/* ANIMALADA SERPIENTE: Se ponen en orden segun su fuerza todos los animales
		 * Si son de la misma especie no se cambia el orden */
		assertEquals(0,Fila.getFila().posicionCarta(c3.getAnimal()));
		assertEquals(1,Fila.getFila().posicionCarta(c2.getAnimal()));
		assertEquals(2,Fila.getFila().posicionCarta(c.getAnimal()));
		assertEquals(3,Fila.getFila().posicionCarta(c1.getAnimal()));
		
		Fila.getFila().eliminarCarta(c);
		Fila.getFila().eliminarCarta(c1);
		Fila.getFila().eliminarCarta(c2);
		Fila.getFila().eliminarCarta(c3);
	}

	@Test
	public void testAnadirCarta() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Fila.getFila().anadirCarta(c);
		assertEquals(c,Fila.getFila().getUnaCarta(0));
	}
	
	@Test
	public void testGetUnaCarta() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Fila.getFila().anadirCarta(c);
		assertEquals(c,Fila.getFila().getUnaCarta(0));
	}
	
	@Test
	public void testEliminarCarta() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Fila.getFila().anadirCarta(c);
		Fila.getFila().eliminarCarta(c);
		assertNull(Fila.getFila().getUnaCarta(0));
	}
	
	@Test
	public void testSetNull() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Fila.getFila().anadirCarta(c);
		Fila.getFila().setNull();
		assertTrue(Fila.getFila().getUnaCarta(0)==null);
	}
	
	@Test
	public void testOrdenarPorFuerza() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Carta d = new Carta("Azul", new Loro());
		Fila.getFila().anadirCarta(c);
		Fila.getFila().anadirCarta(d);
		Fila.getFila().ordenarPorFuerza();
		assertTrue(Fila.getFila().getUnaCarta(0).equals(d));
		assertTrue(Fila.getFila().getUnaCarta(1).equals(c));
	}
	
	@Test
	public void testPosicionCarta() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Carta d = new Carta("Azul", new Loro());
		Fila.getFila().anadirCarta(c);
		Fila.getFila().anadirCarta(d);
		assertTrue(Fila.getFila().posicionCarta(d.getAnimal())==1);
		
	}
	
	@Test
	public void testOrdenarOrdenInverso() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Carta d = new Carta("Azul", new Loro());
		Fila.getFila().anadirCarta(c);
		Fila.getFila().anadirCarta(d);
		Fila.getFila().ordenarOrdenInverso();
		assertTrue(Fila.getFila().getUnaCarta(0).equals(d));
		assertTrue(Fila.getFila().getUnaCarta(1).equals(c));
	}
	
	@Test
	public void testResetear() 
	{
		Fila.getFila().resetear();
		Carta c = new Carta("Azul", new Mofeta());
		Fila.getFila().anadirCarta(c);
		Fila.getFila().resetear();
		assertTrue(Fila.getFila().getUnaCarta(0)==null);
	}
	
	@Test
	public void testRevisarEstadoFila() 
	{
		Fila.getFila().resetear();
		
		Fila.getFila().anadirCarta(new Carta("Azul",AnimalFactory.getAnimalFactory().crearAnimal(1)));
		Fila.getFila().anadirCarta(new Carta("Azul",AnimalFactory.getAnimalFactory().crearAnimal(2)));
		Fila.getFila().anadirCarta(new Carta("Azul",AnimalFactory.getAnimalFactory().crearAnimal(3)));
		Fila.getFila().anadirCarta(new Carta("Azul",AnimalFactory.getAnimalFactory().crearAnimal(4)));
		Fila.getFila().anadirCarta(new Carta("Azul",AnimalFactory.getAnimalFactory().crearAnimal(5)));
				
		Fila.getFila().revisarEstadoFila();
				
		assertEquals(2, Fila.getFila().getSize());
	}
}
