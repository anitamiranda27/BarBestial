package packPruebas;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import packModelo.Animal;
import packModelo.AnimalFactory;
import packModelo.Carta;
import packModelo.Fila;
import packModelo.Juego;
import packModelo.Jugador;
import packModelo.NoHayCartasEnElMazoException;
import packModelo.Ordenador;

public class JugadorTest {

	@Test
	public void testGetJugador() {
		assertNotNull(Jugador.getJugador());
	}

	@Test
	public void testEcharCarta() {
		Jugador.getJugador().repartirCartas("Azul");
		assertTrue(Jugador.getJugador().echarCarta(0).colorIgual("Azul"));;
	}

	@Test
	public void testSetNombre() {
		Jugador.getJugador().setNombre("aa");
		assertTrue(Jugador.getJugador().getNombre()=="aa");
	}

	@Test
	public void testGetNombre() {
		Jugador.getJugador().setNombre("aa");
		assertTrue(Jugador.getJugador().getNombre()=="aa");
	}

	@Test
	public void testResetear() {
		Jugador.getJugador().setNombre("aa");
		Jugador.getJugador().resetear();
		assertTrue(Jugador.getJugador().getNombre()==null);
	}
	
	@Test
	public void testGetUnaCartaMano() {
		try {
			Juego.getJuego().inicializarJuego();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(Jugador.getJugador().getUnaCartaMano(0)!=null);
	}
	
	@Test
	public void testCogerCarta() {
		Jugador.getJugador().resetear();
		
		Jugador.getJugador().repartirCartas("Azul");
	
		try {		
		      Jugador.getJugador().cogerCarta();
		      assertEquals(5, Jugador.getJugador().getManoSize());
		      Jugador.getJugador().cogerCarta();
		      assertEquals(6, Jugador.getJugador().getManoSize());
		      Jugador.getJugador().cogerCarta();
		     assertEquals(7, Jugador.getJugador().getManoSize());
		     Jugador.getJugador().cogerCarta(); //Tiene que saltar la Excepcion NoHayCartasEnElMazo
					
		} catch (NoHayCartasEnElMazoException e) {
		   e.printStackTrace();
		}

	}
}
