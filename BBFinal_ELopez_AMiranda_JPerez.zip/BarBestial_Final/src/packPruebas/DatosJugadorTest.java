package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.DatosJugador;

public class DatosJugadorTest {

	@Test
	public void testDatosJugador() {
		DatosJugador d = new DatosJugador("a", "b");
		assertNotNull(d);
	}

	@Test
	public void testSumarPunto() {
		DatosJugador d = new DatosJugador("a", "b");
		int a = d.getPuntuacion();
		d.sumarPunto();
		assertEquals(a+1, d.getPuntuacion());
	}

	@Test
	public void testGetPuntuacion() {
		DatosJugador d = new DatosJugador("a", "b");
		assertEquals(0, d.getPuntuacion());
	}

	@Test
	public void testDatosCorrectos() {
		DatosJugador d = new DatosJugador("a", "b");
		assertTrue(d.datosCorrectos("a", "b"));
		assertFalse(d.datosCorrectos("c", "b"));
		assertFalse(d.datosCorrectos("c", "d"));
	}

	@Test
	public void testNombreCorrecto() {
		DatosJugador d = new DatosJugador("a", "b");
		assertTrue(d.nombreCorrecto("a"));
	}

	@Test
	public void testGetNombre() {
		DatosJugador d = new DatosJugador("a", "b");
		assertEquals("a",d.getNombre());
	}

}
