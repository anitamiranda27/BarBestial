package packPruebas;

import static org.junit.Assert.*;

import org.junit.Test;

import packModelo.AnimalFactory;
import packModelo.Canguro;
import packModelo.Carta;
import packModelo.Fila;

public class CanguroTest {

	@Test
	public void testHacerAnimalada() //No esta implementado aun
	{
		/* Salta por encima del ultimo o de los dos ultimos animales de la cola sin importar la fuerza
		 *Los elige el jugador
		 */
		
		Carta c = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c);
		Carta c1 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(10));
		Fila.getFila().anadirCarta(c1);
		Carta c2 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(1));
		Fila.getFila().anadirCarta(c2);
		Carta c3 = new Carta("Azul", AnimalFactory.getAnimalFactory().crearAnimal(3));
		Fila.getFila().anadirCarta(c3);
		
		c3.hacerAnimalada("2"); //El jugador indica que quiere que salte a 2 animales
		assertEquals(1, Fila.getFila().posicionCarta(c3.getAnimal())); //Salta desde la posicion 3 a la 1
		c3.hacerAnimalada("1"); //El jugador indica que quiere que salte a 1 animal
		assertEquals(1, Fila.getFila().posicionCarta(c3.getAnimal())); //Salta desde la posicion 1 a la 0
		
	}

	@Test
	public void testCanguro() {
		Canguro c = new Canguro();
		assertNotNull(c);
		assertEquals(3, c.getFuerza());
	}

}
